<?php
/**
 * Plugin Name: OpenAI Key Cleaner
 * Plugin URI: https://example.com
 * Description: Admin tool to clear OpenAI API keys from wp_options
 * Version: 1.0.0
 * Author: Your Name
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class OpenAI_Key_Cleaner {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_post_clear_openai_keys', array($this, 'handle_clear_keys'));
    }
    
    public function add_admin_menu() {
        add_management_page(
            'Clear OpenAI Keys',
            'CLEAR OPENAI KEYS',
            'manage_options',
            'clear-openai-keys',
            array($this, 'render_admin_page')
        );
    }
    
    public function render_admin_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }
        
        // Get all options that might contain OpenAI keys
        $found_keys = $this->find_openai_keys();
        
        ?>
        <div class="wrap">
            <h1>Clear OpenAI API Keys</h1>
            
            <?php if (isset($_GET['cleared']) && $_GET['cleared'] === 'true'): ?>
                <div class="notice notice-success is-dismissible">
                    <p><strong>Success!</strong> <?php echo intval($_GET['count']); ?> OpenAI key(s) have been cleared.</p>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <h2>Found OpenAI Keys</h2>
                
                <?php if (empty($found_keys)): ?>
                    <p>No OpenAI API keys found in wp_options.</p>
                <?php else: ?>
                    <p>Found <strong><?php echo count($found_keys); ?></strong> option(s) containing OpenAI API keys:</p>
                    <ul style="list-style: disc; margin-left: 20px;">
                        <?php foreach ($found_keys as $key): ?>
                            <li><code><?php echo esc_html($key); ?></code></li>
                        <?php endforeach; ?>
                    </ul>
                    
                    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" onsubmit="return confirm('Are you sure you want to clear all OpenAI API keys? This action cannot be undone.');">
                        <?php wp_nonce_field('clear_openai_keys_action', 'clear_openai_keys_nonce'); ?>
                        <input type="hidden" name="action" value="clear_openai_keys">
                        <p>
                            <button type="submit" class="button button-primary">Clear All OpenAI Keys</button>
                        </p>
                    </form>
                <?php endif; ?>
            </div>
            
            <div class="card" style="margin-top: 20px;">
                <h2>About This Tool</h2>
                <p>This tool searches for options in your WordPress database that contain OpenAI API keys (values starting with "sk-") and allows you to clear them.</p>
                <p><strong>Warning:</strong> This action is irreversible. Make sure you have a backup of your keys before clearing them.</p>
            </div>
        </div>
        <?php
    }
    
    private function find_openai_keys() {
        global $wpdb;
        
        $query = "SELECT option_name FROM {$wpdb->options} 
                  WHERE option_value LIKE 'sk-%' 
                  OR option_value LIKE '%\"sk-%'
                  OR option_value LIKE '%sk-proj-%'";
        
        $results = $wpdb->get_col($query);
        
        return $results ? $results : array();
    }
    
    public function handle_clear_keys() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to perform this action.'));
        }
        
        check_admin_referer('clear_openai_keys_action', 'clear_openai_keys_nonce');
        
        $found_keys = $this->find_openai_keys();
        $count = 0;
        
        foreach ($found_keys as $option_name) {
            update_option($option_name, '');
            $count++;
        }
        
        wp_redirect(add_query_arg(
            array(
                'page' => 'clear-openai-keys',
                'cleared' => 'true',
                'count' => $count
            ),
            admin_url('tools.php')
        ));
        exit;
    }
}

// Initialize the plugin
new OpenAI_Key_Cleaner();
