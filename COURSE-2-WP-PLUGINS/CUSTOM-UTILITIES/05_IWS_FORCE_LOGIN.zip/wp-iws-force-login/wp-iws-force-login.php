<?php
/**
 * Plugin Name: ✅ IWS FORCE
 * Plugin URI: https://example.com
 * Description: Requires users to be logged in to view any content on the site
 * Version: 1.0.0
 * Author: Craig West
 * Author URI: https://immortalityai.co.uk
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// Prevent direct access to this file
if (!defined('ABSPATH')) {
    exit;
}


class Force_Login_Plugin {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('template_redirect', array($this, 'force_login'));
        add_action('admin_menu', array($this, 'add_settings_page'));
        add_action('admin_init', array($this, 'register_settings'));
        add_filter('login_redirect', array($this, 'custom_login_redirect'), 10, 3);
    }
    
    /**
     * Force users to log in
     */
    public function force_login() {
        // Don't redirect if user is already logged in
        if (is_user_logged_in()) {
            return;
        }
        
        // Allow access to login, registration, and password reset pages
        $allowed_pages = array(
            'wp-login.php',
            'wp-register.php',
            'wp-signup.php'
        );
        
        // Get the current page
        $current_page = basename($_SERVER['PHP_SELF']);
        
        // Check if current page is in allowed list
        if (in_array($current_page, $allowed_pages)) {
            return;
        }
        
        // Allow AJAX requests
        if (defined('DOING_AJAX') && DOING_AJAX) {
            return;
        }
        
        // Allow REST API requests (optional - comment out if you want to block API)
        if (defined('REST_REQUEST') && REST_REQUEST) {
            return;
        }
        
        // Get whitelist URLs from settings
        $whitelist = get_option('force_login_whitelist', array());
        
        // Check if current URL is whitelisted
        $current_url = home_url($_SERVER['REQUEST_URI']);
        foreach ($whitelist as $url) {
            if (!empty($url) && strpos($current_url, trim($url)) !== false) {
                return;
            }
        }
        
        // Redirect to login page with redirect back parameter
        $redirect_url = wp_login_url($_SERVER['REQUEST_URI']);
        wp_safe_redirect($redirect_url);
        exit;
    }
    
    /**
     * Custom login redirect
     */
    public function custom_login_redirect($redirect_to, $request, $user) {
        // If there's an error or no user, return default
        if (isset($user->errors) && !empty($user->errors)) {
            return $redirect_to;
        }
        
        // OVERRIDE: Always redirect administrators to dashboard
        if (isset($user->roles) && is_array($user->roles)) {
            if (in_array('administrator', $user->roles)) {
                return admin_url();
            }
        }
        
        // Get the custom redirect setting for non-admin users
        $redirect_option = get_option('force_login_redirect_after', 'requested');
        
        switch ($redirect_option) {
            case 'home':
                // Redirect to home page
                return home_url();
                
            case 'dashboard':
                // Redirect to admin dashboard
                return admin_url();
                
            case 'custom':
                // Redirect to custom URL
                $custom_url = get_option('force_login_custom_redirect', home_url());
                return !empty($custom_url) ? $custom_url : home_url();
                
            case 'specific_page':
                // Redirect to specific page
                $page_id = get_option('force_login_redirect_page', 0);
                if ($page_id) {
                    return get_permalink($page_id);
                }
                return home_url();
                
            case 'requested':
            default:
                // Redirect to originally requested page
                if (!empty($request)) {
                    return $request;
                }
                return $redirect_to;
        }
    }
    
    /**
     * Add settings page to admin menu
     */
    public function add_settings_page() {
        add_options_page(
            'IWS Force Login Settings',
            'IWS Force Login',
            'manage_options',
            'force-login-settings',
            array($this, 'render_settings_page')
        );
    }
    
    /**
     * Register plugin settings
     */
    public function register_settings() {
        register_setting('force_login_settings', 'force_login_whitelist');
        register_setting('force_login_settings', 'force_login_redirect_after');
        register_setting('force_login_settings', 'force_login_custom_redirect');
        register_setting('force_login_settings', 'force_login_redirect_page');
        
        // Whitelist section
        add_settings_section(
            'force_login_whitelist_section',
            'URL Whitelist',
            array($this, 'whitelist_section_callback'),
            'force-login-settings'
        );
        
        add_settings_field(
            'force_login_whitelist_field',
            'Whitelisted URLs',
            array($this, 'whitelist_field_callback'),
            'force-login-settings',
            'force_login_whitelist_section'
        );
        
        // Redirect section
        add_settings_section(
            'force_login_redirect_section',
            'Login Redirect Settings',
            array($this, 'redirect_section_callback'),
            'force-login-settings'
        );
        
        add_settings_field(
            'force_login_redirect_field',
            'Redirect After Login',
            array($this, 'redirect_field_callback'),
            'force-login-settings',
            'force_login_redirect_section'
        );
    }
    
    /**
     * Whitelist section description
     */
    public function whitelist_section_callback() {
        echo '<p>Add URLs that should be accessible without logging in (one per line).</p>';
    }
    
    /**
     * Redirect section description
     */
    public function redirect_section_callback() {
        echo '<p>Choose where users should be redirected after successful login.</p>';
        echo '<p style="background: #fff3cd; padding: 10px; border-left: 4px solid #ffc107;"><strong>Note:</strong> Administrators will always be redirected to the dashboard, regardless of these settings.</p>';
    }
    
    /**
     * Whitelist field
     */
    public function whitelist_field_callback() {
        $whitelist = get_option('force_login_whitelist', array());
        $value = is_array($whitelist) ? implode("\n", $whitelist) : '';
        echo '<textarea name="force_login_whitelist" rows="10" cols="50" class="large-text">' . esc_textarea($value) . '</textarea>';
        echo '<p class="description">Enter full or partial URLs, one per line. Example: /about-us or /contact</p>';
    }
    
    /**
     * Redirect field
     */
    public function redirect_field_callback() {
        $redirect_option = get_option('force_login_redirect_after', 'requested');
        $custom_url = get_option('force_login_custom_redirect', '');
        $page_id = get_option('force_login_redirect_page', 0);
        ?>
        <div style="margin-bottom: 15px;">
            <label>
                <input type="radio" name="force_login_redirect_after" value="requested" <?php checked($redirect_option, 'requested'); ?>>
                <strong>Originally Requested Page</strong> (default - user goes to the page they tried to access)
            </label>
        </div>
        
        <div style="margin-bottom: 15px;">
            <label>
                <input type="radio" name="force_login_redirect_after" value="home" <?php checked($redirect_option, 'home'); ?>>
                <strong>Home Page</strong>
            </label>
        </div>
        
        <div style="margin-bottom: 15px;">
            <label>
                <input type="radio" name="force_login_redirect_after" value="dashboard" <?php checked($redirect_option, 'dashboard'); ?>>
                <strong>WordPress Dashboard</strong>
            </label>
        </div>
        
        <div style="margin-bottom: 15px;">
            <label>
                <input type="radio" name="force_login_redirect_after" value="specific_page" <?php checked($redirect_option, 'specific_page'); ?>>
                <strong>Specific Page</strong>
            </label>
            <div style="margin-left: 25px; margin-top: 5px;">
                <?php
                wp_dropdown_pages(array(
                    'name' => 'force_login_redirect_page',
                    'selected' => $page_id,
                    'show_option_none' => '-- Select Page --',
                    'option_none_value' => '0'
                ));
                ?>
            </div>
        </div>
        
        <div style="margin-bottom: 15px;">
            <label>
                <input type="radio" name="force_login_redirect_after" value="custom" <?php checked($redirect_option, 'custom'); ?>>
                <strong>Custom URL</strong>
            </label>
            <div style="margin-left: 25px; margin-top: 5px;">
                <input type="text" name="force_login_custom_redirect" value="<?php echo esc_attr($custom_url); ?>" class="regular-text" placeholder="https://example.com/welcome">
                <p class="description">Enter full URL including https://</p>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Handle form submission
        if (isset($_POST['submit']) && check_admin_referer('force_login_settings-options')) {
            // Save whitelist
            if (isset($_POST['force_login_whitelist'])) {
                $whitelist = array_filter(array_map('trim', explode("\n", $_POST['force_login_whitelist'])));
                update_option('force_login_whitelist', $whitelist);
            }
            
            // Save redirect settings
            if (isset($_POST['force_login_redirect_after'])) {
                update_option('force_login_redirect_after', sanitize_text_field($_POST['force_login_redirect_after']));
            }
            
            if (isset($_POST['force_login_custom_redirect'])) {
                update_option('force_login_custom_redirect', esc_url_raw($_POST['force_login_custom_redirect']));
            }
            
            if (isset($_POST['force_login_redirect_page'])) {
                update_option('force_login_redirect_page', intval($_POST['force_login_redirect_page']));
            }
            
            echo '<div class="updated"><p><strong>Settings saved!</strong></p></div>';
        }
        
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <form method="post" action="">
                <?php
                settings_fields('force_login_settings');
                do_settings_sections('force-login-settings');
                submit_button('Save Settings');
                ?>
            </form>
            
            <div style="margin-top: 30px; padding: 15px; background: #f0f0f1; border-left: 4px solid #2271b1;">
                <h3>💡 Quick Tips</h3>
                <ul>
                    <li><strong>Originally Requested Page:</strong> Best for general sites - users go where they intended</li>
                    <li><strong>Home Page:</strong> Good for simple sites or blogs</li>
                    <li><strong>Specific Page:</strong> Perfect for welcome pages or member dashboards</li>
                    <li><strong>Custom URL:</strong> Use for external redirects or specific paths</li>
                </ul>
            </div>
        </div>
        <?php
    }
}

// Initialize the plugin
new Force_Login_Plugin();