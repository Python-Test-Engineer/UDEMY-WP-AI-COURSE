# WP Tool Use Demo Plugin

A WordPress plugin that demonstrates OpenAI tool calling functionality with a shortcode interface. This plugin allows users to interact with OpenAI's GPT models that support function calling, providing a visual interface to see how AI can use tools to accomplish tasks.

## Features

- **Shortcode Interface**: Easy to embed anywhere in WordPress using `[wp_tool_use]`
- **Multiple Instances**: Can use multiple instances on the same page
- **Tool Calling Demo**: Demonstrates `get_weather()` and `get_sum()` functions
- **Responsive Design**: Works on desktop and mobile devices
- **Security**: Includes nonce verification for form submissions
- **WordPress Standards**: Follows WordPress coding standards and best practices

## Installation

1. Upload the `wp-tool-use` folder to your `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use the shortcode `[wp_tool_use]` in any post or page

## Usage

### Basic Shortcode
```
[wp_tool_use]
```

### Shortcode with Custom Attributes
```
[wp_tool_use 
    title="My Custom Tool Demo" 
    subtitle="Try asking about weather or math" 
    default_prompt="What is 10 + 15?"
]
```

### Available Attributes

- **title**: The main heading for the tool demo (default: "🛠️ OpenAI Tool Calling Demo")
- **subtitle**: The subtitle/description (default: "Demonstrates tool calling with get_weather() and get_sum() functions")
- **default_prompt**: The default prompt in the input field (default: "What's the weather in England?")

## How It Works

The plugin creates an interface where users can:

1. **Enter OpenAI API Key**: Users provide their own OpenAI API key
2. **Enter a Prompt**: Users can ask questions like:
   - "What's the weather?" (triggers `get_weather()` tool)
   - "What is 5 + 3?" (triggers `get_sum()` tool)
3. **View Results**: The interface shows the conversation flow including:
   - API calls to OpenAI
   - Tool calls made by the AI
   - Tool execution results
   - Final AI responses

## Available Tools

### get_weather()
Returns current weather information (simulated):
```
"The current weather is 25°C, sunny with a light breeze."
```

### get_sum(a, b)
Calculates the sum of two numbers:
```
Input: a=5, b=3
Output: "The sum of 5 and 3 is 8."
```

## File Structure

```
wp-tool-use/
├── wp-tool-use.php          # Main plugin file
├── assets/
│   ├── css/
│   │   └── frontend-styles.css
│   └── js/
│       └── frontend-script.js
└── README.md                # This file
```

## Security Features

- **Nonce Verification**: All AJAX requests are verified
- **Input Sanitization**: All user inputs are properly sanitized
- **Direct Access Prevention**: Plugin files cannot be accessed directly
- **Capability Checks**: Proper WordPress capability verification

## Requirements

- WordPress 5.0 or higher
- PHP 7.4 or higher
- Valid OpenAI API key
- Modern web browser with JavaScript enabled

## Customization

### Adding New Tools

To add new tools, modify the JavaScript in `assets/js/frontend-script.js`:

1. Add the tool function:
```javascript
function my_new_tool(param1, param2) {
    // Your tool logic here
    return "Tool result";
}
```

2. Add the tool to the processToolCall function:
```javascript
function processToolCall(toolName, toolInput) {
    if (toolName === 'my_new_tool') {
        return my_new_tool(toolInput.param1, toolInput.param2);
    }
    // ... existing tools
}
```

3. Add the tool definition to the tools array in handleToolCalling function.

### Styling

Customize the appearance by modifying `assets/css/frontend-styles.css`. The plugin uses CSS custom properties and BEM-style class names for easy customization.

## Troubleshooting

### Plugin Not Working
1. Ensure the plugin is activated
2. Check that your theme supports shortcodes
3. Verify JavaScript is enabled in your browser
4. Check browser console for any JavaScript errors

### OpenAI API Issues
1. Verify your API key is correct
2. Check that your OpenAI account has sufficient credits
3. Ensure you're using a model that supports function calling (gpt-4o-mini, gpt-4, etc.)

## Support

For issues and feature requests, please check the plugin documentation or contact the developer.

## License

This plugin is licensed under the GPL v2 or later.

## Changelog

### Version 1.0.0
- Initial release
- Basic tool calling functionality
- Shortcode interface
- Responsive design
- Security features implemented

# Quick Start Guide

## Installation
1. Copy the `wp-tool-use` folder to `/wp-content/plugins/`
2. Activate the plugin in WordPress admin
3. Add `[wp_tool_use]` shortcode to any post/page

## Basic Usage
```
[wp_tool_use]
```

## Custom Usage
```
[wp_tool_use 
    title="Weather & Math Demo" 
    subtitle="Ask me anything!" 
    default_prompt="What is 7 + 8?"
]
```

## Test Prompts
Try these prompts to see tool calling in action:
- "What's the weather?" → Uses get_weather() tool
- "What is 15 + 25?" → Uses get_sum() tool  
- "Calculate 100 + 200" → Uses get_sum() tool

## Requirements
- WordPress 5.0+
- PHP 7.4+
- OpenAI API key
- JavaScript enabled
