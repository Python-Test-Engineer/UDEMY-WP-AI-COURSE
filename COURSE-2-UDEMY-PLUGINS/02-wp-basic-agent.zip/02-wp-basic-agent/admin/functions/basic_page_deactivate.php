<?php

function wp_basic_agent_deactivate() {
   // Clean up if needed
}
