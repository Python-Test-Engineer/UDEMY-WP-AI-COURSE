# Simple WP RAG Query Plugin

A simplified WordPress plugin that demonstrates dynamic RAG (Retrieval-Augmented Generation) by taking a single query and returning relevant context plus an AI-generated answer.

## Overview

This plugin simplifies the complex chatbot functionality to focus on the core RAG concept:

1. **User enters a query** (e.g., "What cordless tools do you have?")
2. **System searches for relevant content** using FTS (Full-Text Search) REST API
3. **AI generates an answer** using the retrieved context
4. **Results are displayed** showing the query, retrieved context, and AI answer

## Key Features

- ✅ **Simple Interface**: Just an input field and submit button
- ✅ **Dynamic RAG**: Real-time content retrieval from WordPress database
- ✅ **Clear Results Display**: Shows query, context, and AI answer separately
- ✅ **Educational**: Perfect for demonstrating RAG concepts to students
- ✅ **Secure**: Server-side API key handling
- ✅ **No Chat History**: Each query is independent

## File Structure

```
wp-rag-query.php                 # Main plugin file
admin/
├── admin-settings.php           # Admin settings for API key
└── assets/css/admin-styles.css  # Admin styling
functions/
└── rag-query-handler.php        # AJAX handler for queries
shortcodes/
├── rag-query-shortcode.php      # Frontend shortcode
└── assets/
    ├── css/frontend-styles.css  # Frontend styling
    └── js/frontend-script.js    # Frontend JavaScript
```

## Installation & Setup

1. **Activate the plugin** in WordPress admin
2. **Configure API Key**:
   - Go to `06 RAG Query` in admin menu
   - Enter your OpenAI API key
   - Save settings
3. **Add to a page/post**:
   - Use shortcode: `[wp_rag_query]`
   - The form will appear on the frontend

## How It Works

### The RAG Process

```
User Query → FTS Search API → Retrieved Context → OpenAI API → AI Answer → Display Results
     ↓              ↓              ↓              ↓              ↓            ↓
"What cordless   Searches WordPress  Finds relevant   AI uses context  Generates    Shows:
tools?"         posts for "cordless"  product info     to answer         answer      Query + Context + Answer
```

### Example Output

**Query:** What cordless tools do you have?

**RAG Context (Retrieved Information):**
```
Cordless Drill 20V Professional-grade motor with variable speed control...
Vacuum Cleaner Cordless Stick with 40 minutes runtime...
Angle Grinder Cordless with safety features...
```

**AI Answer:**
Based on our product database, we offer several cordless tools including:
- A professional 20V cordless drill with variable speed control
- A cordless stick vacuum cleaner with 40 minutes runtime
- A cordless angle grinder with advanced safety features

## Dependencies

- **OpenAI API Key**: Required for AI generation
- **FTS REST API**: Assumes `/wp-json/fts/v1/search` endpoint exists (from another plugin)
- **WordPress**: Standard WordPress installation

## Customization

### Change the Search API

Edit `functions/rag-query-handler.php`:

```php
function wp_rag_query_fetch_context($query) {
    $search_url = site_url('/wp-json/your-api/v1/search?query=' . urlencode($query));
    // ... rest of function
}
```

### Modify AI Prompt

Edit the system prompt in `functions/rag-query-handler.php`:

```php
$system_content = "Your custom system prompt here";
```

### Styling

- **Frontend**: Edit `shortcodes/assets/css/frontend-styles.css`
- **Admin**: Edit `admin/assets/css/admin-styles.css`

## Educational Value

This plugin is designed to teach:

1. **RAG Concepts**: How retrieval + generation works
2. **API Integration**: Secure handling of external APIs
3. **WordPress Development**: Shortcodes, AJAX, admin menus
4. **User Experience**: Simple, focused interface
5. **Security**: Server-side key management

## Comparison to Full Chatbot

| Feature | Simple RAG Query | Full Chatbot |
|---------|------------------|--------------|
| **Complexity** | Low | High |
| **Memory** | None | Persistent |
| **Interface** | Form | Chat UI |
| **Use Case** | Education/Demo | Production Chat |
| **Setup** | Quick | Complex |
| **Features** | Core RAG | Full conversation |

## Testing

1. **Enter a query** like "What cordless tools do you have?"
2. **Check if context appears** - if not, FTS API may not be available
3. **Verify AI answer** uses the context information
4. **Test error handling** with invalid API key

## Troubleshooting

### No Context Retrieved
- Check if FTS REST API is active
- Verify the endpoint URL in code
- Test the API directly: `/wp-json/fts/v1/search?query=test`

### OpenAI API Errors
- Verify API key is correct
- Check API key permissions
- Monitor OpenAI dashboard for usage

### Shortcode Not Working
- Ensure plugin is activated
- Check for JavaScript errors in browser console
- Verify shortcode is: `[wp_rag_query]`

## Future Enhancements

- Add support for multiple AI providers
- Implement caching for repeated queries
- Add query history/logs for admin
- Support for different search backends
- Customizable result formatting
