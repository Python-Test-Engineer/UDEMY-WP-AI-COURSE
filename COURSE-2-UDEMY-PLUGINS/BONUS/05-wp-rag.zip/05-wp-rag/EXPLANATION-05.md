# WordPress RAG Query Plugin (05-wp-rag) - Detailed Explanation

## 🎯 Plugin Overview

The **WordPress RAG Query Plugin** implements a Retrieval-Augmented Generation (RAG) system that enables intelligent question-answering about WordPress content. This plugin demonstrates advanced AI integration concepts including context retrieval, prompt engineering, API orchestration, and frontend AJAX interactions.

## 📋 What This Plugin Does

This plugin creates an AI-powered query system that:

1. **Retrieves Relevant Context**: Uses the FTS plugin to find relevant WordPress post content
2. **Generates AI Responses**: Sends context-augmented prompts to OpenAI's GPT models
3. **Provides Frontend Interface**: Offers a shortcode-based form for user queries
4. **Ensures Context Accuracy**: Forces AI to prioritize retrieved content over general knowledge

## 🏗️ Architecture & Components

### Core Files Structure
```
05-wp-rag/
├── index.php                      # Security file (empty)
├── functions/
│   └── rag-query-handler.php     # Core RAG processing logic
├── admin/
│   ├── admin-settings.php        # API key configuration
│   ├── assets/
│   │   ├── css/
│   │   │   └── admin-styles.css  # Admin interface styling
│   │   └── js/
│   │       └── chatbot.js        # Admin JavaScript (placeholder)
│   ├── functions/
│   │   └── enqueue-assets.php    # Asset management
│   └── includes/
│       └── inc-system-prompt.php # AI system prompt configuration
├── shortcodes/
│   ├── rag-query-shortcode.php   # Frontend shortcode handler
│   └── assets/
│       ├── css/
│       │   └── frontend-styles.css # Frontend styling
│       └── js/
│           └── frontend-script.js  # Frontend JavaScript
├── classes/                       # Future class-based extensions
├── EXPLANATION-05.md             # This documentation
└── templates/                    # Future template files
```

## How It Works

### 1. Query Processing Flow

1. User submits a query via AJAX
2. Plugin fetches relevant context from FTS REST API (`/wp-json/fts/v1/search`)
3. Context is combined with system instructions
4. Request is sent to OpenAI API
5. AI response is returned to user

### 2. Context Retrieval

The plugin uses the FTS plugin's REST API endpoint:
```
GET /wp-json/fts/v1/search?query={user_query}&count=3
```

This returns:
- `context`: Concatenated content from matching posts
- `post_ids`: Array of relevant post IDs
- `debug`: Information about the search process

### 3. AI Integration

**System Prompt Structure:**
```
You are a helpful assistant. Answer questions using the provided context. Do not use general knowledge - base your response only on the context given.

CONTEXT: {retrieved_context}

{user_query}
```

**API Request:**
- Model: `gpt-4o-mini`
- Max tokens: 1024
- Messages include system prompt + user query

### 4. Response Format

```json
{
  "query": "user's question",
  "rag_context": "retrieved context string",
  "ai_answer": "AI generated response"
}
```

## Key Features

### Context-Aware Responses
- Ensures AI answers are based on actual WordPress content
- Prevents hallucination by restricting to provided context
- Falls back to general knowledge only when no context is available

### AJAX Integration
- Non-blocking queries via WordPress AJAX API
- Proper nonce verification for security
- Error handling for API failures

### Admin Configuration
- Secure API key storage using WordPress options
- Admin menu integration
- Settings validation

## Dependencies

- **04 WordPress FTS Plugin**: Required for context retrieval
- **OpenAI API**: Requires valid API key for AI responses
- **WordPress REST API**: For FTS search functionality

## Security Features

- Nonce verification on all AJAX requests
- Sanitized user input
- API key stored securely in WordPress options
- Admin capability checks

## Current Limitations

- No frontend shortcode implemented (mentioned in admin but not coded)
- No frontend assets or JavaScript handlers
- Limited error handling and user feedback
- No conversation memory or multi-turn conversations

## Usage

1. Install and activate both FTS and RAG plugins
2. Configure OpenAI API key in admin settings
3. Ensure FTS table is populated with post data
4. Make AJAX calls to `wp_ajax_rag_query_submit` endpoint

## AJAX Request Example

```javascript
$.ajax({
  url: ajaxurl,
  type: 'POST',
  data: {
    action: 'rag_query_submit',
    nonce: 'your_nonce',
    query: 'What tools do you offer?'
  },
  success: function(response) {
    console.log(response.data.ai_answer);
  }
});
```

## 🔧 Technical Implementation

### 1. AJAX Handler (functions/rag-query-handler.php)

#### Core Function: wp_rag_query_submit()
```php
function wp_rag_query_submit() {
    // 1. Verify nonce and validate inputs
    // 2. Fetch context via FTS API
    // 3. Build OpenAI messages with context
    // 4. Make API request and return response
}
```

#### Context Retrieval: wp_rag_query_fetch_context()
```php
function wp_rag_query_fetch_context($query) {
    $search_url = site_url('/wp-json/fts/v1/search?query=' . urlencode($query) . '&count=3');
    $response = wp_remote_get($search_url);
    // Parse and return context or empty string
}
```

### 2. Frontend Shortcode (shortcodes/rag-query-shortcode.php)

#### Shortcode Registration
```php
add_shortcode('wp_rag_query', 'wp_rag_query_shortcode');
```

#### HTML Structure
- Query input form
- Loading indicator
- Results display with sections for query, context, and answer
- JavaScript data passing for AJAX

### 3. Admin Configuration (admin/admin-settings.php)

#### Settings Registration
```php
register_setting('wp_rag_query_settings', 'wp_rag_query_api_key');
```

#### Admin Menu Integration
- Adds "05 RAG" menu item
- Settings form with API key input
- Nonce-protected form submission

## 🎨 Frontend Interface Design

### Shortcode Output Structure
```html
<div class="wp-rag-query-wrapper">
    <div class="wp-rag-query-container">
        <div class="wp-rag-query-header">
            <h3>Dynamic RAG Query Demo</h3>
        </div>
        <div class="wp-rag-query-form">
            <input id="wp-rag-query-input" placeholder="e.g., What cordless tools do you have?">
            <button id="wp-rag-query-submit">Submit Query</button>
        </div>
        <div id="wp-rag-query-results">
            <!-- Results displayed here -->
        </div>
    </div>
</div>
```

### JavaScript Integration (frontend-script.js)
- AJAX form submission handling
- Loading state management
- Dynamic results display
- Error handling and user feedback

### CSS Styling (frontend-styles.css)
- Responsive form design
- Loading animations
- Result formatting with proper typography
- Error/success state styling

## 🚀 Usage Examples

### 1. Frontend Shortcode Usage
```php
// Add to any post or page
[wp_rag_query]
```

### 2. Programmatic AJAX Usage
```javascript
$.ajax({
  url: wpRagQuery.ajaxurl,
  type: 'POST',
  data: {
    action: 'rag_query_submit',
    nonce: wpRagQuery.nonce,
    query: 'What products do you offer?'
  },
  success: function(response) {
    if (response.success) {
      $('#wp-rag-query-answer').html(response.data.ai_answer);
      $('#wp-rag-query-context').html(response.data.rag_context);
    }
  }
});
```

### 3. Backend Integration Example
```php
// Direct function call (for custom implementations)
$context = wp_rag_query_fetch_context('search query');
if (!empty($context)) {
    // Use context for AI processing
}
```

## 📊 Performance Considerations

### API Optimization
- **Request Batching**: Single API call per query with context
- **Response Caching**: Consider caching frequent queries
- **Timeout Management**: 60-second timeout for OpenAI API calls

### Context Processing
- **Text Truncation**: FTS API limits context size
- **Relevance Filtering**: Only top 3 most relevant posts
- **Memory Efficiency**: Streaming context concatenation

### Frontend Performance
- **Conditional Asset Loading**: Scripts/styles only loaded when shortcode present
- **Progressive Enhancement**: Form works without JavaScript
- **Loading States**: User feedback during processing

## 🛠️ Development Concepts Demonstrated

### WordPress Development Skills
1. **AJAX Integration**: Server-side processing with client-side feedback
2. **Shortcode API**: Custom shortcode creation and asset management
3. **Admin Interfaces**: Settings API usage and admin menu integration
4. **Security Practices**: Nonce verification and input sanitization
5. **REST API Consumption**: Making requests to WordPress REST API endpoints

### AI Integration Concepts
1. **Prompt Engineering**: Crafting effective system prompts for RAG
2. **Context Augmentation**: Combining retrieved data with AI instructions
3. **API Orchestration**: Coordinating multiple API calls (FTS + OpenAI)
4. **Response Processing**: Handling and formatting AI-generated content

### Advanced Concepts
1. **Retrieval-Augmented Generation**: Implementing RAG architecture
2. **Context Window Management**: Optimizing context size for AI models
3. **Error Handling**: Graceful degradation when APIs fail
4. **User Experience Design**: Loading states and progressive disclosure

## 🔐 Security Features

- **Nonce Verification**: All AJAX requests protected with WordPress nonces
- **Input Sanitization**: User queries sanitized with `sanitize_text_field()`
- **API Key Protection**: Keys stored securely in WordPress options table
- **Permission Checks**: Admin-only access to settings
- **XSS Prevention**: Proper output escaping in HTML generation
- **CSRF Protection**: Form submissions protected against cross-site attacks

## 🎓 Learning Outcomes

After studying this plugin, students will understand:

1. **AI Integration Patterns**
   - How to integrate external AI APIs with WordPress
   - Prompt engineering for domain-specific applications
   - Handling API rate limits and error responses

2. **RAG Architecture**
   - Retrieval-Augmented Generation concepts
   - Context retrieval and augmentation techniques
   - Balancing retrieved data with AI generation

3. **Advanced WordPress AJAX**
   - Building complex AJAX workflows
   - Frontend/backend communication patterns
   - Progressive enhancement techniques

4. **API Orchestration**
   - Coordinating multiple API calls
   - Error handling across service boundaries
   - Response aggregation and formatting

5. **User Experience Design**
   - Loading states and user feedback
   - Progressive disclosure of information
   - Error handling from user's perspective

## 🚀 Next Steps & Extensions

### Potential Enhancements
1. **Conversation Memory**
   - Maintain conversation history across queries
   - Context accumulation for multi-turn conversations

2. **Advanced Context Processing**
   - Semantic chunking of retrieved content
   - Relevance scoring and filtering
   - Multi-source context aggregation

3. **Performance Optimizations**
   - Response caching with Redis/Memcached
   - Asynchronous processing with background jobs
   - Context preprocessing and indexing

4. **Additional Features**
   - Query suggestions and autocomplete
   - Export functionality for responses
   - Analytics and usage tracking

5. **Integration Options**
   - Support for multiple AI providers (Claude, Gemini)
   - Custom post type support beyond posts
   - Multilingual query processing

### Alternative AI Models
- **GPT-4**: For more complex reasoning tasks
- **Claude**: For different prompt response patterns
- **Local Models**: Integration with Ollama or similar

### Advanced RAG Techniques
- **Query Expansion**: Expanding user queries for better retrieval
- **Re-ranking**: Advanced relevance scoring algorithms
- **Hybrid Search**: Combining keyword and semantic search

This plugin serves as a practical example of modern AI integration with WordPress, demonstrating how to build intelligent, context-aware applications that leverage both retrieval systems and generative AI capabilities.

## Recent Updates

The system prompt was updated to be more explicit about using context:
- AI is instructed to "base your response only on the context given"
- Context is clearly labeled as "CONTEXT:" in the prompt
- Ensures domain-specific information takes precedence over general AI knowledge
