<?php
// RAG Query Handler - simplified for single query processing

// Handle AJAX request for RAG query
add_action('wp_ajax_rag_query_submit', 'wp_rag_query_submit');
add_action('wp_ajax_nopriv_rag_query_submit', 'wp_rag_query_submit'); // Allow non-logged-in users

/**
 * Main function to handle RAG query submission
 */
function wp_rag_query_submit() {
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'], 'rag_query_nonce')) {
        wp_send_json_error(array('message' => 'Security check failed'));
        return;
    }

    // Get and validate API key
    $api_key = get_option('wp_rag_query_api_key', '');
    if (empty($api_key)) {
        wp_send_json_error(array('message' => 'API key not configured'));
        return;
    }

    // Get and validate query
    $query = isset($_POST['query']) ? sanitize_text_field($_POST['query']) : '';
    if (empty($query)) {
        wp_send_json_error(array('message' => 'Please enter a query'));
        return;
    }

    // Step 1: Fetch RAG context
    $rag_context = wp_rag_query_fetch_context($query);

    // Step 2: Build messages for OpenAI
    $messages = array();

    // System prompt
    $system_content = "You are a helpful assistant.";
    if (!empty($rag_context)) {
        $system_content .= " Answer questions using the provided context. Do not use general knowledge - base your response only on the context given.";
        $system_content .= "\n\nCONTEXT: " . $rag_context;
    } else {
        $system_content .= " Answer based on your general knowledge.";
    }
    $messages[] = array('role' => 'system', 'content' => $system_content);

    // User query
    $messages[] = array('role' => 'user', 'content' => $query);

    // Step 3: Call OpenAI API
    $response = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
        'timeout' => 60,
        'headers' => array(
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $api_key
        ),
        'body' => json_encode(array(
            'model' => 'gpt-4o-mini',
            'messages' => $messages,
            'max_tokens' => 1024
        ))
    ));

    if (is_wp_error($response)) {
        wp_send_json_error(array('message' => 'API request failed: ' . $response->get_error_message()));
        return;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (isset($data['error'])) {
        wp_send_json_error(array('message' => 'OpenAI API error: ' . $data['error']['message']));
        return;
    }

    if (!isset($data['choices'][0]['message']['content'])) {
        wp_send_json_error(array('message' => 'No response from OpenAI'));
        return;
    }

    $ai_answer = $data['choices'][0]['message']['content'];

    // Step 4: Format response
    $result = array(
        'query' => $query,
        'rag_context' => $rag_context,
        'ai_answer' => $ai_answer
    );

    wp_send_json_success($result);
}

/**
 * Fetch context from FTS REST API
 */
function wp_rag_query_fetch_context($query) {
    $search_url = site_url('/wp-json/fts/v1/search?query=' . urlencode($query) . '&count=3');

    $search_response = wp_remote_get($search_url, array(
        'timeout' => 10
    ));

    if (!is_wp_error($search_response)) {
        $search_body = wp_remote_retrieve_body($search_response);
        $search_data = json_decode($search_body, true);

        if (isset($search_data['context']) && !empty($search_data['context'])) {
            return $search_data['context'];
        }
    }

    return ''; // No context found
}
