/**
 * WP RAG Query Frontend JavaScript
 */

jQuery(document).ready(function($) {
    'use strict';

    const $input = $('#wp-rag-query-input');
    const $submitBtn = $('#wp-rag-query-submit');
    const $loading = $('#wp-rag-query-loading');
    const $results = $('#wp-rag-query-results');
    const $queryDisplay = $('#wp-rag-query-display');
    const $contextSection = $('#rag-context-section');
    const $context = $('#wp-rag-query-context');
    const $answer = $('#wp-rag-query-answer');

    // Submit query
    $submitBtn.on('click', function(e) {
        e.preventDefault();

        const query = $input.val().trim();
        if (!query) {
            alert('Please enter a query');
            return;
        }

        // Disable button and show loading
        $submitBtn.prop('disabled', true).text('Processing...');
        $results.hide();
        $loading.show();

        // Send AJAX request
        $.ajax({
            url: wpRagQuery.ajaxurl,
            type: 'POST',
            data: {
                action: 'rag_query_submit',
                nonce: wpRagQuery.nonce,
                query: query
            },
            success: function(response) {
                if (response.success) {
                    displayResults(response.data);
                } else {
                    alert('Error: ' + response.data.message);
                }
            },
            error: function(xhr, status, error) {
                alert('Request failed: ' + error);
            },
            complete: function() {
                // Re-enable button and hide loading
                $submitBtn.prop('disabled', false).text('Submit Query');
                $loading.hide();
            }
        });
    });

    // Allow Enter key to submit
    $input.on('keypress', function(e) {
        if (e.which === 13) { // Enter key
            $submitBtn.click();
        }
    });

    // Display results
    function displayResults(data) {
        $queryDisplay.text(data.query);

        if (data.rag_context) {
            $context.text(data.rag_context);
            $contextSection.show();
        } else {
            $contextSection.hide();
        }

        $answer.html(data.ai_answer.replace(/\n/g, '<br>'));
        $results.show();

        // Scroll to results
        $results[0].scrollIntoView({ behavior: 'smooth' });
    }
});
