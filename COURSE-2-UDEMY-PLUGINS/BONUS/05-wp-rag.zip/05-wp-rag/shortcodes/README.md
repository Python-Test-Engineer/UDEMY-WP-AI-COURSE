# ChatBot Shortcode Documentation

## Overview
This shortcode allows you to display the ChatBot with Memory on any WordPress page or post.

## Usage

Simply add the following shortcode to any page or post where you want the chatbot to appear:

```
[wp_chatbot]
```

### Using a Custom API Key

You can optionally specify a custom OpenAI API key for a specific instance of the chatbot:

```
[wp_chatbot api_key="sk-your-custom-api-key-here"]
```

This is useful if:
- You want different pages/posts to use different API keys
- You want to track usage separately for different chatbot instances
- You want to provide API keys without storing them in WordPress settings

## Features

- **Full Functionality**: The frontend chatbot has all the same features as the admin version
- **Conversation Memory**: Uses localStorage to maintain conversation history across page refreshes
- **Separate Storage**: Frontend chat history is stored separately from admin chat history
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Auto-configured**: Uses the same API key and system prompt configured in the admin panel

## Requirements

- The OpenAI API key must be configured in the WordPress admin panel (ChatBot Settings)
- The chatbot will display an error message if the API key is not configured

## Styling

The frontend chatbot comes with its own styling that is separate from the admin styles. The styles are:

- Contained and won't conflict with your theme
- Responsive and mobile-friendly
- Uses WordPress color scheme for consistency
- WhatsApp-style chat interface

## Technical Details

### Files Structure
```
shortcodes/
├── chatbot-shortcode.php          # Main shortcode handler
├── assets/
│   ├── css/
│   │   └── frontend-styles.css    # Frontend styles
│   └── js/
│       └── frontend-chatbot.js    # Frontend JavaScript
└── README.md                       # This file
```

### Local Storage Key
The frontend chatbot uses the key `wp_chatbot_frontend_history` in localStorage, which is separate from the admin chatbot's `wp_chatbot_history` key.

### AJAX Integration
The frontend chatbot uses the same WordPress AJAX handler as the admin version (`chatbot_send_message` action), ensuring consistent functionality.

## Examples

### Basic Usage
Add to any page content:
```
[wp_chatbot]
```

### In a Template File
If you need to add the chatbot directly in a template file:
```php
<?php echo do_shortcode('[wp_chatbot]'); ?>
```

## Troubleshooting

**Chatbot not appearing:**
- Check that the shortcode is spelled correctly: `[wp_chatbot]`
- Ensure the plugin is activated

**"ChatBot is not configured" error:**
- Go to WordPress Admin → ChatBot Settings
- Enter and save your OpenAI API key

**Chat not working:**
- Check browser console for JavaScript errors
- Verify API key is valid
- Check that you have internet connectivity

## Support

For issues or questions, please refer to the main plugin documentation or contact the plugin author.
