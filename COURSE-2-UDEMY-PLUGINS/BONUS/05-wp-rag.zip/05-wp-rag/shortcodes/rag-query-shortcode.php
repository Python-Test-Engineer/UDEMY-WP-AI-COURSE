<?php
/**
 * RAG Query Shortcode Handler
 *
 * Provides shortcode functionality to display the RAG query form on the frontend
 * Usage: [wp_rag_query]
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Render the RAG Query shortcode
 *
 * @param array $atts Shortcode attributes
 * @return string HTML output for the RAG query form
 */
function wp_rag_query_shortcode($atts) {
    // Parse shortcode attributes (none for now)
    $atts = shortcode_atts(array(), $atts, 'wp_rag_query');

    // Check if API key is configured
    $api_key = get_option('wp_rag_query_api_key', '');

    // Start output buffering
    ob_start();
    ?>

    <div class="wp-rag-query-wrapper">
        <?php if (empty($api_key)): ?>
            <div class="wp-rag-query-notice wp-rag-query-error">
                <p>RAG Query is not configured. Please contact the site administrator.</p>
            </div>
        <?php else: ?>

            <div class="wp-rag-query-container">
                <div class="wp-rag-query-header">
                    <h3>Dynamic RAG Query Demo</h3>
                    <p>Enter a query to see how RAG (Retrieval-Augmented Generation) works. The system will search for relevant content and generate an AI answer.</p>
                </div>

                <div class="wp-rag-query-form">
                    <label for="wp-rag-query-input">Your Query:</label>
                    <input
                        type="text"
                        id="wp-rag-query-input"
                        placeholder="e.g., What cordless tools do you have?"
                        value="Tell me about FOAM products you have"
                    />
                    <button id="wp-rag-query-submit" class="wp-rag-query-button">Submit Query</button>
                </div>

                <div id="wp-rag-query-loading" class="wp-rag-query-loading" style="display: none;">
                    Searching and generating answer...
                </div>

                <div id="wp-rag-query-results" class="wp-rag-query-results" style="display: none;">
                    <div class="wp-rag-query-section">
                        <h4>Query:</h4>
                        <p id="wp-rag-query-display"></p>
                    </div>

                    <div class="wp-rag-query-section" id="rag-context-section" style="display: none;">
                        <h4>RAG Context (Retrieved Information):</h4>
                        <div id="wp-rag-query-context" class="wp-rag-query-context"></div>
                    </div>

                    <div class="wp-rag-query-section">
                        <h4>AI Answer:</h4>
                        <div id="wp-rag-query-answer" class="wp-rag-query-answer"></div>
                    </div>
                </div>
            </div>

        <?php endif; ?>
    </div>

    <script type="text/javascript">
        // Pass data to JavaScript
        window.wpRagQuery = {
            ajaxurl: '<?php echo admin_url('admin-ajax.php'); ?>',
            nonce: '<?php echo wp_create_nonce('rag_query_nonce'); ?>'
        };
    </script>

    <?php

    return ob_get_clean();
}

// Register the shortcode
add_shortcode('wp_rag_query', 'wp_rag_query_shortcode');

/**
 * Enqueue frontend assets for the RAG query shortcode
 */
function wp_rag_query_enqueue_frontend_assets() {
    // Only enqueue if we're on a page/post that has the shortcode
    global $post;

    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'wp_rag_query')) {
        // Enqueue frontend CSS
        wp_enqueue_style(
            'wp-rag-query-frontend-styles',
            WP_RAG_QUERY_PLUGIN_URL . 'shortcodes/assets/css/frontend-styles.css',
            array(),
            WP_RAG_QUERY_VERSION
        );

        // Enqueue frontend JavaScript
        wp_enqueue_script(
            'wp-rag-query-frontend-script',
            WP_RAG_QUERY_PLUGIN_URL . 'shortcodes/assets/js/frontend-script.js',
            array('jquery'),
            WP_RAG_QUERY_VERSION,
            true
        );
    }
}
add_action('wp_enqueue_scripts', 'wp_rag_query_enqueue_frontend_assets');
