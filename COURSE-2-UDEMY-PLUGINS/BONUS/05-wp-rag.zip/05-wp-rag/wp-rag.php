<?php
/*
Plugin Name: ✅ 05 UDEMY RAG
Description: A simple WordPress plugin that demonstrates dynamic RAG (Retrieval-Augmented Generation) by taking a query and returning relevant context plus AI answer.
Version: 1.0.0
Author: Craig West
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('WP_RAG_QUERY_VERSION', '1.0.0');
define('WP_RAG_QUERY_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WP_RAG_QUERY_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include required files
require_once WP_RAG_QUERY_PLUGIN_DIR . 'admin/admin-settings.php';
require_once WP_RAG_QUERY_PLUGIN_DIR . 'functions/rag-query-handler.php';
require_once WP_RAG_QUERY_PLUGIN_DIR . 'shortcodes/rag-query-shortcode.php';

// Activation hook
register_activation_hook(__FILE__, 'wp_rag_query_activate');

function wp_rag_query_activate() {
    // Set default options if needed
    add_option('wp_rag_query_api_key', '');
}

// Enqueue admin assets
add_action('admin_enqueue_scripts', 'wp_rag_query_enqueue_admin_assets');

function wp_rag_query_enqueue_admin_assets($hook) {
    if ($hook !== 'toplevel_page_wp-rag-query-settings') {
        return;
    }

    wp_enqueue_style(
        'wp-rag-query-admin-styles',
        WP_RAG_QUERY_PLUGIN_URL . 'admin/assets/css/admin-styles.css',
        array(),
        WP_RAG_QUERY_VERSION
    );
}
