<?php
// Admin settings for RAG Query plugin

// Register settings
add_action('admin_init', 'wp_rag_query_register_settings');

function wp_rag_query_register_settings() {
    register_setting('wp_rag_query_settings', 'wp_rag_query_api_key');
}

// Add admin menu
add_action('admin_menu', 'wp_rag_query_admin_menu');

function wp_rag_query_admin_menu() {
    add_menu_page(
        '05 RAG Query',           // Page title
        '05 RAG',           // Menu title
        'manage_options',         // Capability
        'wp-rag-query-settings',  // Menu slug
        'wp_rag_query_settings_page', // Callback function
        'dashicons-search',       // Icon
        3.5                    // Position
    );
}

// Render settings page
function wp_rag_query_settings_page() {
    $api_key = get_option('wp_rag_query_api_key', '');

    // Handle form submission
    if (isset($_POST['save_rag_query_api_key']) && check_admin_referer('wp_rag_query_save_nonce')) {
        $api_key = sanitize_text_field($_POST['wp_rag_query_api_key']);
        update_option('wp_rag_query_api_key', $api_key);
        echo '<div class="notice notice-success"><p>API key saved successfully!</p></div>';
    }

    ?>
    <div class="wrap">
        <h1>RAG Query Settings</h1>

        <div class="card">
            <h2>OpenAI API Configuration</h2>
            <form method="post" action="">
                <?php wp_nonce_field('wp_rag_query_save_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="wp_rag_query_api_key">API KEY</label>
                        </th>
                        <td>
                            <input
                                type="password"
                                id="wp_rag_query_api_key"
                                name="wp_rag_query_api_key"
                                value="<?php echo esc_attr($api_key); ?>"
                                class="regular-text"
                                placeholder="sk-..."
                                required
                            />
                            <p class="description">
                                Enter your OpenAI API key. This is required for the RAG query functionality.
                            </p>
                        </td>
                    </tr>
                </table>
                <p class="submit">
                    <input type="submit" name="save_rag_query_api_key" class="button button-primary" value="Save API Key" />
                </p>
            </form>
        </div>

        <div class="card">
            <h2>Shortcode Usage</h2>
            <p>Use the following shortcode to display the RAG query form on any page or post:</p>
            <code>[wp_rag_query]</code>
            <p>This will show a simple form where users can enter a query, and it will display the RAG context and AI answer.</p>
        </div>
    </div>
    <?php
}
