<?php
// Get the saved API key from WordPress options
$api_key = get_option('wp_chatbot_api_key', '');

// Check if API key should be visible
$show_key = get_transient('wp_chatbot_show_key_' . get_current_user_id());

// Check for success message
$message = get_transient('wp_chatbot_message');
if ($message) {
    delete_transient('wp_chatbot_message');
}

// Include system prompt
$system_prompt = '';
$system_prompt_file = WP_CHATBOT_PLUGIN_DIR . 'admin/includes/inc-system-prompt.php';
if (file_exists($system_prompt_file)) {
    ob_start();
    include $system_prompt_file;
    $system_prompt = ob_get_clean();
}
?>

<div class="wrap">
    <h1 class="title"><?php _e('ChatBot with Memory', 'wp-chatbot'); ?></h1>

    <div class="dashboard-container">

        <!-- API CONFIGURATION SECTION -->
        <div class="dashboard-card">
            <h2><?php _e('API Configuration', 'wp-chatbot'); ?></h2>
            
            <?php if ($message): ?>
                <div class="notice notice-success inline">
                    <p><?php echo esc_html($message); ?></p>
                </div>
            <?php endif; ?>
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="wp_chatbot_api_key"><?php _e('OpenAI API Key', 'wp-chatbot'); ?></label>
                    </th>
                    <td>
                        <div style="display: flex; align-items: flex-start; gap: 10px;">
                            <!-- Form for API Key Input and Save -->
                            <form method="post" action="" style="flex: 1; display: flex; gap: 10px;">
                                <?php wp_nonce_field('wp_chatbot_save_key_nonce'); ?>
                                
                                <input 
                                    type="<?php echo $show_key ? 'text' : 'password'; ?>" 
                                    id="wp_chatbot_api_key" 
                                    name="wp_chatbot_api_key" 
                                    value="<?php echo esc_attr($api_key); ?>" 
                                    class="regular-text" 
                                    placeholder="sk-..."
                                    required
                                />
                                
                                <input type="submit" name="save_chatbot_api_key" class="button button-primary" value="<?php _e('Save API Key', 'wp-chatbot'); ?>" />
                            </form>
                            
                            <!-- Separate Form for Show/Hide Toggle -->
                            <form method="post" action="">
                                <?php wp_nonce_field('wp_chatbot_toggle_nonce'); ?>
                                <button 
                                    type="submit" 
                                    name="toggle_chatbot_key_visibility" 
                                    class="button"
                                    style="padding: 0 10px; height: 30px; min-width: 60px;"
                                    title="<?php _e('Show/Hide API Key', 'wp-chatbot'); ?>"
                                >
                                    <?php echo $show_key ? __('Hide', 'wp-chatbot') : __('Show', 'wp-chatbot'); ?>
                                </button>
                            </form>
                        </div>
                        <p class="description">
                            <?php if (!empty($api_key)): ?>
                                <span style="color: green;">✓ <?php _e('API key is configured and ready to use.', 'wp-chatbot'); ?></span>
                            <?php else: ?>
                                <span style="color: #d63638;">⚠ <?php _e('Please enter and save your OpenAI API key to use the chatbot.', 'wp-chatbot'); ?></span>
                            <?php endif; ?>
                        </p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- CHATBOT INTERFACE -->
        <div class="dashboard-card">
            <h2><?php _e('ChatBot with Memory', 'wp-chatbot'); ?></h2>
            
            <div class="chatbot-info">
                <p><?php _e('This chatbot maintains conversation history using browser localStorage. Your conversation will persist across page refreshes.', 'wp-chatbot'); ?></p>
            </div>

            <div id="chatContainer" class="chat-container">
                <div id="messages" class="messages-area"></div>
            </div>

            <div id="inputContainer" class="input-container">
                <input type="text" id="messageInput" placeholder="<?php _e('Type your message...', 'wp-chatbot'); ?>" value="What cordless tools do you have?">
                <button id="sendBtn" class="button button-primary"><?php _e('Send', 'wp-chatbot'); ?></button>
                <button id="clearBtn" class="button button-secondary clear-btn"><?php _e('Clear Chat', 'wp-chatbot'); ?></button>
            </div>
        </div>

    </div>
</div>

<!-- Hidden data for JavaScript -->
<script type="text/javascript">
    // Pass system prompt to JavaScript
    window.wpChatbotSystemPrompt = <?php echo json_encode($system_prompt); ?>;
</script>
