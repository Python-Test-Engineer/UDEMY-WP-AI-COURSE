<?php
// Render the settings page

function wp_chatbot_render_settings_page() {
    // Check user capabilities
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }
    
    // Include the settings template
    include WP_CHATBOT_PLUGIN_DIR . 'admin/templates/chatbot-settings-template.php';
}
