# Browser Local Storage: A Comprehensive Guide

Browser Local Storage is a web storage API that allows you to store key-value pairs in a web browser with no expiration date. The data persists even after the browser is closed and reopened, making it useful for saving user preferences, application state, and other data that should survive browser sessions.

## Key Characteristics

**Capacity**: Typically 5-10MB per domain (much larger than cookies' ~4KB limit)

**Persistence**: Data remains until explicitly deleted by the user or the application

**Scope**: Data is specific to the protocol and domain (origin)

**Synchronous**: All operations are synchronous and block the main thread

**Storage Format**: Can only store strings (though JSON can be used for complex data)

## Basic API Methods

```javascript
// Store data
localStorage.setItem('key', 'value');

// Retrieve data
const value = localStorage.getItem('key');

// Remove specific item
localStorage.removeItem('key');

// Clear all data
localStorage.clear();

// Get number of stored items
const itemCount = localStorage.length;

// Get key by index
const keyName = localStorage.key(0);
```

## Practical Examples

### Example 1: Storing User Preferences

```javascript
// Storing a theme preference
function setTheme(theme) {
    localStorage.setItem('userTheme', theme);
    applyTheme(theme);
}

function loadTheme() {
    const theme = localStorage.getItem('userTheme') || 'light';
    applyTheme(theme);
}

function applyTheme(theme) {
    document.body.className = theme + '-theme';
}

// Load theme when page loads
window.addEventListener('load', loadTheme);
```

### Example 2: Storing Complex Objects with JSON

Since localStorage only stores strings, you need to serialize objects:

```javascript
// Storing an object
const user = {
    name: 'Alice',
    email: 'alice@example.com',
    preferences: {
        notifications: true,
        language: 'en'
    }
};

localStorage.setItem('user', JSON.stringify(user));

// Retrieving and parsing the object
const storedUser = JSON.parse(localStorage.getItem('user'));
console.log(storedUser.name); // 'Alice'
```

### Example 3: Shopping Cart Persistence

```javascript
class ShoppingCart {
    constructor() {
        this.items = this.loadCart();
    }

    loadCart() {
        const cartData = localStorage.getItem('shoppingCart');
        return cartData ? JSON.parse(cartData) : [];
    }

    saveCart() {
        localStorage.setItem('shoppingCart', JSON.stringify(this.items));
    }

    addItem(product) {
        this.items.push(product);
        this.saveCart();
    }

    removeItem(productId) {
        this.items = this.items.filter(item => item.id !== productId);
        this.saveCart();
    }

    clearCart() {
        this.items = [];
        localStorage.removeItem('shoppingCart');
    }
}

// Usage
const cart = new ShoppingCart();
cart.addItem({ id: 1, name: 'Laptop', price: 999 });
```

### Example 4: Form Auto-Save

```javascript
const form = document.getElementById('myForm');
const inputs = form.querySelectorAll('input, textarea');

// Save form data as user types
inputs.forEach(input => {
    // Load saved value
    const savedValue = localStorage.getItem(`form_${input.name}`);
    if (savedValue) {
        input.value = savedValue;
    }

    // Save on input
    input.addEventListener('input', (e) => {
        localStorage.setItem(`form_${e.target.name}`, e.target.value);
    });
});

// Clear saved data on successful submit
form.addEventListener('submit', (e) => {
    e.preventDefault();
    // ... handle form submission
    
    // Clear saved form data
    inputs.forEach(input => {
        localStorage.removeItem(`form_${input.name}`);
    });
});
```

### Example 5: Tracking Last Visit

```javascript
function trackVisit() {
    const lastVisit = localStorage.getItem('lastVisit');
    const currentVisit = new Date().toISOString();
    
    if (lastVisit) {
        console.log(`Welcome back! Last visit: ${new Date(lastVisit).toLocaleDateString()}`);
    } else {
        console.log('Welcome, first-time visitor!');
    }
    
    localStorage.setItem('lastVisit', currentVisit);
}

trackVisit();
```

## Important Considerations

**Security**: Don't store sensitive information like passwords or tokens in localStorage, as it's accessible via JavaScript and vulnerable to XSS attacks.

**Size Limits**: Be mindful of the 5-10MB storage limit. Check for quota exceeded errors:

```javascript
try {
    localStorage.setItem('key', largeData);
} catch (e) {
    if (e.name === 'QuotaExceededError') {
        console.error('Storage quota exceeded!');
    }
}
```

**Browser Support**: localStorage is supported in all modern browsers, but always check for availability:

```javascript
if (typeof(Storage) !== "undefined") {
    // localStorage is available
    localStorage.setItem('test', 'value');
} else {
    // Fallback for older browsers
    console.log('LocalStorage not supported');
}
```

**Privacy Mode**: Some browsers disable localStorage in private/incognito mode or clear it when the session ends.

## localStorage vs sessionStorage

JavaScript also provides `sessionStorage`, which works identically but only persists for the browser session:

```javascript
// Data cleared when tab/window is closed
sessionStorage.setItem('tempData', 'temporary');

// Same API as localStorage
sessionStorage.getItem('tempData');
sessionStorage.removeItem('tempData');
```

Local storage is a powerful tool for creating responsive, user-friendly web applications that remember state across sessions. Just remember to handle errors gracefully and never store sensitive information!