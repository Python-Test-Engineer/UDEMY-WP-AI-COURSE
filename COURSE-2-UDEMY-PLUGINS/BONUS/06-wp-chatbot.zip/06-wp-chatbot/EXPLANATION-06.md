# EXPLANATION-06: WordPress ChatBot Plugin with FTS RAG Integration

## Overview

This document provides a detailed explanation of the **06-wp-chatbot** plugin, which implements a conversational AI chatbot with persistent memory using OpenAI's API. The plugin integrates with a local Full-Text Search (FTS) REST API to provide context-aware responses using Retrieval-Augmented Generation (RAG). The chatbot demonstrates browser-based conversation history management, WordPress AJAX handlers, and a clean admin interface.

---

## Table of Contents

1. [Plugin Architecture](#plugin-architecture)
2. [Key Features](#key-features)
3. [File Structure](#file-structure)
4. [Code Breakdown](#code-breakdown)
5. [How Memory Works](#how-memory-works)
6. [FTS RAG Integration - Local Full-Text Search](#fts-rag-integration)
7. [Data Flow](#data-flow)
8. [Security Implementation](#security-implementation)
9. [Comparison: HTML vs WordPress Implementation](#comparison-html-vs-wordpress-implementation)

---

## Plugin Architecture

```
07-wp-chatbot/
├── wp-chatbot.php                    # Main plugin file
├── admin/
│   ├── functions/
│   │   ├── admin-hooks.php           # WordPress admin menu registration
│   │   ├── render-admin-page.php     # Page rendering logic
│   │   └── enqueue-assets.php        # CSS/JS asset loading
│   ├── templates/
│   │   └── chatbot-settings-template.php  # Admin UI template
│   ├── assets/
│   │   ├── css/
│   │   │   └── admin-styles.css      # Chatbot styling
│   │   └── js/
│   │       └── chatbot.js            # Client-side chatbot logic
│   └── includes/
│       └── inc-system-prompt.php     # System prompt content
├── functions/
│   └── chatbot-api-handler.php       # WordPress AJAX handler
└── classes/
    └── .gitkeep                       # Reserved for future OOP implementation
```

---

## Key Features

### 1. **Conversation Memory**
- Uses browser localStorage to persist chat history
- Maintains conversation context across page refreshes
- Includes system prompt in every API call

### 2. **WordPress AJAX Integration**
- Secure server-side API key handling
- Nonce-based security
- No client-side API key exposure

### 3. **Clean Admin Interface**
- WhatsApp-like chat UI
- Real-time message rendering
- Loading states and error handling

### 4. **Security Features**
- API key stored in WordPress options
- Show/hide API key toggle with transients
- Permission checks for admin access
- AJAX nonce verification

---

## Code Breakdown

### 1. Main Plugin File: `wp-chatbot.php`

```php
<?php
/*
Plugin Name: ✅ 07 UDEMY CHATBOT WITH MEMORY
Description: A ChatBot plugin for WordPress that integrates with OpenAI's API 
             and includes conversation memory using localStorage.
Version: 1.0.0
Author: Craig West
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}
```

**Purpose:** Plugin header that WordPress reads to identify and load the plugin.

#### Constants Definition

```php
// Define plugin constants
define('WP_CHATBOT_VERSION', '1.0.0');
define('WP_CHATBOT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WP_CHATBOT_PLUGIN_URL', plugin_dir_url(__FILE__));
```

**Why?** Constants provide:
- Easy version management for cache busting
- Consistent file path references
- URL generation for assets

#### Settings Registration

```php
function wp_chatbot_register_settings() {
    register_setting('wp_chatbot_settings', 'wp_chatbot_api_key');
}
add_action('admin_init', 'wp_chatbot_register_settings');
```

**Purpose:** Registers the API key setting in WordPress options table.

#### Form Processing

```php
function wp_chatbot_process_forms() {
    if (!current_user_can('manage_options')) {
        return;
    }
    
    // Handle API key visibility toggle
    if (isset($_POST['toggle_chatbot_key_visibility']) && 
        check_admin_referer('wp_chatbot_toggle_nonce')) {
        
        $is_visible = get_transient('wp_chatbot_show_key_' . get_current_user_id());
        
        if ($is_visible) {
            delete_transient('wp_chatbot_show_key_' . get_current_user_id());
        } else {
            set_transient('wp_chatbot_show_key_' . get_current_user_id(), true, 3600);
        }
        
        wp_redirect(admin_url('admin.php?page=wp-chatbot-settings'));
        exit;
    }
}
```

**Key Concepts:**
- `current_user_can('manage_options')`: Permission check (admin-only)
- `check_admin_referer()`: Validates nonce for security
- `get_transient()`: User-specific temporary storage (1 hour expiry)
- `wp_redirect()`: Prevents form resubmission

---

### 2. Admin Menu Registration: `admin/functions/admin-hooks.php`

```php
function wp_chatbot_settings_menu() {
    add_menu_page(
        '07 CHATBOT',              // Page title
        '07 CHATBOT',              // Menu title
        'manage_options',          // Capability required
        'wp-chatbot-settings',     // Menu slug (unique identifier)
        'wp_chatbot_render_settings_page', // Callback function
        'dashicons-format-chat',   // Icon
        3.7                        // Position (top-level, after Dashboard)
    );
}
add_action('admin_menu', 'wp_chatbot_settings_menu');
```

**Menu Position Explained:**
- `3.7` places the menu item at the top level (not in Settings submenu)
- Position numbers:
  - `2` = Dashboard
  - `3` = Posts
  - `3.7` = Custom position after Dashboard
  - `80` = Settings

---

### 3. Asset Enqueuing: `admin/functions/enqueue-assets.php`

```php
function wp_chatbot_enqueue_admin_assets($hook) {
    // Only load on our plugin's admin page
    if ($hook !== 'toplevel_page_wp-chatbot-settings') {
        return;
    }
    
    // Enqueue admin styles
    wp_enqueue_style(
        'wp-chatbot-admin-styles',
        WP_CHATBOT_PLUGIN_URL . 'admin/assets/css/admin-styles.css',
        array(),
        WP_CHATBOT_VERSION
    );
    
    // Enqueue chatbot JavaScript
    wp_enqueue_script(
        'wp-chatbot-js',
        WP_CHATBOT_PLUGIN_URL . 'admin/assets/js/chatbot.js',
        array('jquery'),                    // Dependencies
        WP_CHATBOT_VERSION,
        true                                 // Load in footer
    );
    
    // Localize script - pass data from PHP to JavaScript
    wp_localize_script('wp-chatbot-js', 'wpChatbot', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('chatbot_nonce')
    ));
}
```

**Key Concepts:**

1. **Hook Filtering:** Only loads assets on our specific admin page
2. **Version Cache Busting:** Using `WP_CHATBOT_VERSION` forces browser cache refresh on updates
3. **wp_localize_script:** Passes server-side data to JavaScript:
   - `ajaxurl`: WordPress AJAX endpoint
   - `nonce`: Security token for AJAX requests

---

### 4. AJAX Handler: `functions/chatbot-api-handler.php`

```php
add_action('wp_ajax_chatbot_send_message', 'wp_chatbot_send_message');

function wp_chatbot_send_message() {
    // Verify nonce
    check_ajax_referer('chatbot_nonce', 'nonce');
    
    // Check user permissions
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Unauthorized access'));
        return;
    }
    
    // Get the API key
    $api_key = get_option('wp_chatbot_api_key');
    
    if (empty($api_key)) {
        wp_send_json_error(array('message' => 'API key not configured'));
        return;
    }
    
    // Get the messages array from the request
    $messages = isset($_POST['messages']) ? 
                json_decode(stripslashes($_POST['messages']), true) : array();
    
    if (empty($messages)) {
        wp_send_json_error(array('message' => 'No messages provided'));
        return;
    }
    
    // Make request to OpenAI
    $response = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
        'timeout' => 60,
        'headers' => array(
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $api_key
        ),
        'body' => json_encode(array(
            'model' => 'gpt-4o-mini',
            'messages' => $messages,
            'max_tokens' => 1024
        ))
    ));
    
    // Check for errors
    if (is_wp_error($response)) {
        wp_send_json_error(array('message' => $response->get_error_message()));
        return;
    }
    
    // Get response body
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);
    
    // Return the assistant's response
    if (isset($data['choices'][0]['message']['content'])) {
        wp_send_json_success(array(
            'message' => $data['choices'][0]['message']['content']
        ));
    } else {
        wp_send_json_error(array('message' => 'No response from OpenAI'));
    }
}
```

**Security Layers:**

1. **Nonce Verification:** `check_ajax_referer()` validates request came from our form
2. **Permission Check:** Only administrators can use the chatbot
3. **API Key Server-Side:** Never exposed to browser
4. **Data Validation:** Checks for empty messages before API call

**WordPress HTTP API:**
- `wp_remote_post()`: WordPress wrapper for HTTP requests
- Handles SSL certificates automatically
- Returns WP_Error on failure
- More secure than raw cURL

---

### 5. JavaScript Client: `admin/assets/js/chatbot.js`

#### Message Storage Using localStorage

```javascript
// Initialize messages array with system prompt
let messages = [{ role: 'system', content: systemPrompt }];

// Load messages from localStorage
function loadMessages() {
    const saved = localStorage.getItem('wp_chatbot_history');
    if (saved) {
        try {
            messages = JSON.parse(saved);
            // Ensure system prompt is at the start
            if (!messages[0] || messages[0].role !== 'system') {
                messages.unshift({ role: 'system', content: systemPrompt });
            }
        } catch (e) {
            console.error('Error loading chat history:', e);
            messages = [{ role: 'system', content: systemPrompt }];
        }
    }
    renderMessages();
}

// Save messages to localStorage
function saveMessages() {
    try {
        localStorage.setItem('wp_chatbot_history', JSON.stringify(messages));
    } catch (e) {
        console.error('Error saving chat history:', e);
    }
}
```

**Why localStorage?**
- Persists across page refreshes
- No server storage needed
- Per-domain storage (secure)
- 5-10MB storage limit (sufficient for chat history)

#### Rendering Messages

```javascript
function renderMessages() {
    messagesDiv.innerHTML = '';
    // Skip system message (index 0) when rendering
    messages.slice(1).forEach(msg => {
        const msgDiv = document.createElement('div');
        msgDiv.className = `message ${msg.role}`;
        msgDiv.innerHTML = msg.content; // Supports HTML formatting
        messagesDiv.appendChild(msgDiv);
    });
    scrollToBottom();
}
```

**Key Points:**
- `messages.slice(1)`: Skips system prompt (only sent to API, not displayed)
- `.innerHTML`: Allows AI to return formatted HTML
- Dynamic class names (`user` or `assistant`) for styling

#### Sending Messages via AJAX

```javascript
async function sendMessage(userMessage) {
    // Add user message
    messages.push({ role: 'user', content: userMessage });
    saveMessages();
    renderMessages();

    // Create FormData for AJAX request
    const formData = new FormData();
    formData.append('action', 'chatbot_send_message');
    formData.append('nonce', wpChatbot.nonce);
    formData.append('messages', JSON.stringify(messages));

    // Send request to WordPress AJAX handler
    const response = await fetch(wpChatbot.ajaxurl, {
        method: 'POST',
        body: formData
    });

    const data = await response.json();

    if (data.success) {
        // Add assistant response
        const assistantMessage = data.data.message;
        messages.push({ role: 'assistant', content: assistantMessage });
        saveMessages();
        renderMessages();
    }
}
```

**AJAX Flow:**
1. User types message → Added to messages array
2. Save to localStorage (for persistence)
3. Send entire conversation history to server
4. Server forwards to OpenAI with API key
5. Response returned, added to messages array
6. Save again and re-render

---

## How Memory Works

### Message Array Structure

```javascript
messages = [
    { role: 'system', content: 'You are a helpful assistant...' },
    { role: 'user', content: 'What is the capital of France?' },
    { role: 'assistant', content: 'The capital of France is Paris.' },
    { role: 'user', content: 'What about England?' },
    { role: 'assistant', content: 'The capital of England is London.' }
]
```

### Why Send Entire History?

OpenAI's API is **stateless** - it has no memory. To maintain context:

```javascript
// WRONG - Only sends last message (no context)
const body = JSON.stringify({
    model: 'gpt-4o-mini',
    messages: [{ role: 'user', content: userMessage }]
});

// CORRECT - Sends full conversation
const body = JSON.stringify({
    model: 'gpt-4o-mini',
    messages: messages  // Entire array including system prompt
});
```

**Example Conversation:**

```
User: "What's the capital of France?"
AI: "Paris"

User: "What about that city's population?"
```

Without history, AI doesn't know "that city" = Paris.  
With history, AI sees the full conversation and answers correctly.

---

## RAG Integration - Retrieval-Augmented Generation

### Overview

**RAG (Retrieval-Augmented Generation)** is a technique that enhances AI responses by fetching relevant information from a knowledge base before generating an answer. This plugin integrates RAG to answer domain-specific questions about ecommerce products stored in the WordPress database.

### The Problem RAG Solves

Without RAG:
```
User: "Tell me about cordless tools"
AI: "I don't have information about your specific products"
```

With RAG:
```
User: "Tell me about cordless tools"
System: [Fetches product data from database]
AI: "Based on our products, we have a Vacuum Cleaner Cordless Stick with 40 minutes runtime..."
```

### Architecture

```
┌──────────────────┐
│  User Query      │
│  "cordless tools"│
└────────┬─────────┘
         │
         ▼
┌──────────────────────────────────────────┐
│ AJAX Handler: chatbot-api-handler.php   │
│                                          │
│ 1. Extract user query from messages[]   │
│ 2. Call Hybrid Search REST API          │
│ 3. Retrieve relevant context            │
│ 4. Inject context into messages[]       │
│ 5. Send to OpenAI                       │
└────────┬─────────────────────────────────┘
         │
         ▼
┌──────────────────────────────────────────┐
│ Hybrid Search REST API                   │
│ https://mydigitalagent.co.uk/udemy/     │
│ wp-json/hybrid-search/v1/search?query    │
│                                          │
│ Returns:                                 │
│ {                                        │
│   "query": "cordless tools",             │
│   "context": "Product descriptions...",  │
│   "fts_post_ids": [168],                │
│   "semantic_post_ids": [168, 187, 155]  │
│ }                                        │
└────────┬─────────────────────────────────┘
         │
         ▼
┌──────────────────────────────────────────┐
│ OpenAI receives enhanced messages:       │
│                                          │
│ [                                        │
│   { role: 'system', content: prompt },   │
│   { role: 'system', content:            │
│     'Use the following product info...'  │
│     + RAG context                       │
│   },                                     │
│   { role: 'user', content: 'cordless...' }│
│ ]                                        │
└────────┬─────────────────────────────────┘
         │
         ▼
┌──────────────────────────────────────────┐
│ Response formatted with RAG:             │
│                                          │
│ <RAG>                                    │
│ Vacuum Cleaner Cordless Stick...         │
│ </RAG>                                   │
│ ---------                                │
│ Based on our products, we offer...       │
└──────────────────────────────────────────┘
```

---

### Code Implementation

#### Step 1: Extract User Query

```php
// Get the latest user message as the query
$user_query = '';
$rag_context = ''; // Store RAG context for response

foreach (array_reverse($messages) as $message) {
    if (isset($message['role']) && $message['role'] === 'user') {
        $user_query = $message['content'];
        break;
    }
}
```

**Why iterate in reverse?**  
The most recent user message is at the end of the array. Reversing allows us to find it quickly without processing the entire conversation history.

---

#### Step 2: Fetch RAG Context from Local FTS REST API

```php
// Fetch context from local FTS REST API if we have a query
if (!empty($user_query)) {
    // Use local FTS REST API endpoint with 5 results for better context
    $search_url = home_url('/wp-json/fts/v1/search?query=' . urlencode($user_query) . '&count=5');
    
    $search_response = wp_remote_get($search_url, array(
        'timeout' => 10
    ));
    
    // If successful, process the response
    if (!is_wp_error($search_response)) {
        $search_body = wp_remote_retrieve_body($search_response);
        $search_data = json_decode($search_body, true);
        
        if (isset($search_data['context']) && !empty($search_data['context'])) {
            $rag_context = $search_data['context'];
        }
    }
}
```

**API Response Structure:**
```json
{
  "query": "blenders",
  "context": "BLENDER High-Speed 1400W Professional-grade motor blends toughest ingredients including ice and frozen fruit. Variable speed control and pulse function provide precise blending. 64-ounce BPA-free pitcher makes large batches for whole family. Self-cleaning feature simplifies cleanup with water and drop of soap.",
  "post_ids": [172, 328, 333],
  "debug": {
    "table_name": "wp_posts_fts",
    "total_posts_in_table": "88",
    "search_method": "success"
  }
}
```

**Key Components:**
- `context`: The actual text content retrieved from the WordPress database
- `post_ids`: Array of matching WordPress post IDs
- `debug`: Additional information for troubleshooting
- **Local API**: Uses `home_url('/wp-json/fts/v1/search')` instead of external services

---

#### Step 3: Inject RAG Context into Messages Array

```php
if (isset($search_data['context']) && !empty($search_data['context'])) {
    $rag_context = $search_data['context'];
    
    // Add RAG context as a system message before the user query
    $context_message = array(
        'role' => 'system',
        'content' => 'Use the following product information from our database to answer the user\'s question. Base your answer ONLY on this information: ' . $rag_context
    );
    
    // Insert context message before the last message (the user's query)
    array_splice($messages, -1, 0, array($context_message));
}
```

**Message Array Before RAG:**
```php
[
    ['role' => 'system', 'content' => 'You are a helpful assistant...'],
    ['role' => 'user', 'content' => 'What are cordless tools?']
]
```

**Message Array After RAG Injection:**
```php
[
    ['role' => 'system', 'content' => 'You are a helpful assistant...'],
    ['role' => 'system', 'content' => 'Use the following product information from our database to answer the user\'s question. Base your answer ONLY on this information: Vacuum Cleaner Cordless Stick...'],
    ['role' => 'user', 'content' => 'What are cordless tools?']
]
```

**Why use `array_splice()`?**  
Inserts the RAG context AS a system message BEFORE the user's query, ensuring the AI sees the context immediately before processing the question.

---

#### Step 4: Format Response with RAG Tags

```php
// Return the assistant's response
if (isset($data['choices'][0]['message']['content'])) {
    $assistant_message = $data['choices'][0]['message']['content'];
    
    // Prepend RAG context to the response if available
    if (!empty($rag_context)) {
        $assistant_message = "<RAG>\n" . $rag_context . "\n</RAG>\n---------\n" . $assistant_message;
    }
    
    wp_send_json_success(array(
        'message' => $assistant_message
    ));
}
```

**Example Output:**
```
<RAG>
Vacuum Cleaner Cordless Stick
Powerful cordless cleaning with up to 40 minutes of fade-free runtime. Converts to handheld vacuum for furniture, stairs, and car interior. LED headlights illuminate hidden dust and debris. HEPA filtration.
</RAG>
---------
Based on our product database, we have cordless tools including a high-performance Vacuum Cleaner Cordless Stick. This versatile cleaning tool offers up to 40 minutes of continuous runtime and can easily convert into a handheld unit for furniture, stairs, and car interiors. It features LED headlights to help you spot hidden dust and includes HEPA filtration for cleaner air.
```

---

### RAG Benefits

#### 1. **Domain-Specific Knowledge**
- Answers based on YOUR data (products, services, content)
- Not limited to AI's training data cutoff
- Always up-to-date with your latest content

#### 2. **Accuracy**
- Reduces hallucinations (AI making up information)
- Grounded responses based on real data
- Explicit instruction: "Base your answer ONLY on this information"

#### 3. **Transparency**
- Users see the source data (`<RAG>` section)
- Can verify AI's interpretation
- Builds trust in the system

#### 4. **Cost-Effective**
- No need to fine-tune models
- Works with any OpenAI model
- Can update data without retraining

---

### Hybrid Search Explained

The REST API uses **hybrid search**, combining two approaches:

#### 1. Full-Text Search (FTS)
- Traditional keyword matching
- Fast and accurate for exact matches
- Good for product names, SKUs, specific terms

#### 2. Semantic Search
- Uses vector embeddings (AI-powered)
- Understands meaning and context
- Finds conceptually similar content

**Example:**

```
Query: "cordless cleaning device"

Full-Text Search finds:
- "Vacuum Cleaner Cordless Stick" ← Direct match

Semantic Search finds:
- "Handheld Dustbuster Pro" ← Similar concept
- "Portable Steam Cleaner" ← Related product
- "Battery-Powered Floor Sweeper" ← Contextually relevant
```

**Why Hybrid?**
- Best of both worlds
- Catches exact matches (FTS) AND similar concepts (semantic)
- More comprehensive results

---

### RAG Data Flow Example

**User Query:** "Tell me about cordless tools"

**Step-by-Step:**

1. **JavaScript sends message:**
```javascript
{
  messages: [
    { role: 'system', content: 'You are a helpful assistant...' },
    { role: 'user', content: 'Tell me about cordless tools' }
  ]
}
```

2. **PHP Handler extracts query:**
```php
$user_query = 'Tell me about cordless tools';
```

3. **PHP calls REST API:**
```
GET https://mydigitalagent.co.uk/udemy/wp-json/hybrid-search/v1/search?query=Tell%20me%20about%20cordless%20tools
```

4. **API returns context:**
```json
{
  "context": "Vacuum Cleaner Cordless Stick\n..."
}
```

5. **PHP injects RAG into messages:**
```php
$messages = [
    ['role' => 'system', 'content' => 'You are a helpful assistant...'],
    ['role' => 'system', 'content' => 'Use the following product information... Vacuum Cleaner Cordless Stick...'],
    ['role' => 'user', 'content' => 'Tell me about cordless tools']
]
```

6. **PHP sends to OpenAI:**
```
POST https://api.openai.com/v1/chat/completions
```

7. **OpenAI generates response:**
```
"Based on the products available, we have cordless tools including..."
```

8. **PHP formats with RAG tags:**
```
<RAG>
Vacuum Cleaner Cordless Stick...
</RAG>
---------
Based on the products available...
```

9. **JavaScript displays in chat:**
```
[Assistant bubble with both RAG content and AI response]
```

---

### Error Handling

```php
// If API call fails, chatbot still works (graceful degradation)
if (is_wp_error($search_response)) {
    // No context added, but conversation continues
    // AI will respond based on general knowledge
}

// If no context returned, no RAG section shown
if (empty($rag_context)) {
    // Response is just the AI's answer without RAG tags
}
```

**Why this matters:**
- Plugin doesn't break if REST API is down
- Users still get responses (may be less accurate)
- Logs any errors for debugging

---

### Performance Considerations

#### 1. **Timeout Settings**
```php
$search_response = wp_remote_get($search_url, array(
    'timeout' => 10  // 10 seconds max
));
```
- Prevents long wait times
- Fails fast if API is slow
- Continues without RAG if timeout

#### 2. **Caching Opportunities**
Future enhancement:
```php
// Check transient cache first
$cache_key = 'rag_' . md5($user_query);
$cached_context = get_transient($cache_key);

if ($cached_context) {
    $rag_context = $cached_context;
} else {
    // Fetch from API and cache for 1 hour
    $rag_context = fetch_from_api($user_query);
    set_transient($cache_key, $rag_context, 3600);
}
```

#### 3. **API Call Optimization**
- Only fetches RAG for user messages (not every API call)
- Uses GET request (cacheable by proxy/CDN)
- URL-encodes query properly

---

### Testing RAG Integration

#### Test 1: Product Query
```
User: "Do you have cordless tools?"
Expected: Shows RAG section with product data + AI response about products
```

#### Test 2: Non-Product Query
```
User: "What is 2+2?"
Expected: No RAG section (no relevant database content) + AI answers normally
```

#### Test 3: Multiple Products
```
User: "Compare cordless vacuums"
Expected: RAG shows multiple product contexts + AI compares them
```

#### Test 4: API Failure
```
Simulate: REST API down
Expected: Chat continues without RAG section (graceful degradation)
```

---

### Complete RAG Code Section

Here's the full RAG integration in `functions/chatbot-api-handler.php`:

```php
// *********************************************************************************************
// RAG Integration - Fetch relevant context from hybrid search API
// Get the latest user message as the query
$user_query = '';
$rag_context = ''; // Store RAG context for response

foreach (array_reverse($messages) as $message) {
    if (isset($message['role']) && $message['role'] === 'user') {
        $user_query = $message['content'];
        break;
    }
}

// Fetch context from hybrid search API if we have a query
if (!empty($user_query)) {
    $search_url = 'https://mydigitalagent.co.uk/udemy/wp-json/hybrid-search/v1/search?query=' . urlencode($user_query);
    
    $search_response = wp_remote_get($search_url, array(
        'timeout' => 10
    ));
    
    // If successful, add context to messages
    if (!is_wp_error($search_response)) {
        $search_body = wp_remote_retrieve_body($search_response);
        $search_data = json_decode($search_body, true);
        
        if (isset($search_data['context']) && !empty($search_data['context'])) {
            $rag_context = $search_data['context'];
            
            // Add RAG context as a system message before the user query
            $context_message = array(
                'role' => 'system',
                'content' => 'Use the following product information from our database to answer the user\'s question. Base your answer ONLY on this information: ' . $rag_context
            );
            
            // Insert context message before the last message (which should be the user's query)
            array_splice($messages, -1, 0, array($context_message));
        }
    }
}
// *********************************************************************************************
```

---

### RAG vs Fine-Tuning

| Feature | RAG | Fine-Tuning |
|---------|-----|-------------|
| **Cost** | Low (just API calls) | High (training costs) |
| **Update Speed** | Instant (update database) | Slow (retrain model) |
| **Data Requirements** | Any amount | Large datasets needed |
| **Accuracy** | High with good data | Very high with enough training |
| **Use Case** | Dynamic content, products | Fixed behaviors, style |

**When to use RAG (this plugin):**
- Ecommerce product catalogs
- Frequently updated content
- Company-specific information
- Documentation/knowledge bases

**When to use Fine-Tuning:**
- Specific writing style
- Custom behaviors
- Specialized terminology
- Domain-specific reasoning

---

### Future RAG Enhancements

1. **Multiple Sources:**
```php
// Fetch from multiple APIs
$product_context = fetch_products($query);
$blog_context = fetch_blog_posts($query);
$faq_context = fetch_faqs($query);

$combined_context = $product_context . "\n\n" . $blog_context . "\n\n" . $faq_context;
```

2. **Context Ranking:**
```php
// Show most relevant context first
usort($search_data['semantic_post_ids'], function($a, $b) {
    return $b['relevance_score'] - $a['relevance_score'];
});
```

3. **Token Management:**
```php
// Limit context length to avoid token limits
$rag_context = substr($search_data['context'], 0, 1000); // Max 1000 chars
```

4. **Source Attribution:**
```php
// Include post IDs in response
$assistant_message .= "\n\nSources: Posts " . implode(', ', $search_data['semantic_post_ids']);
```

---

## Data Flow

### Complete Request Lifecycle

```
┌─────────────────┐
│  User Types     │
│  "Capital of    │
│   England?"     │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ JavaScript       │
│ 1. Add to array │
│ 2. Save to      │
│    localStorage │
│ 3. Render UI    │
└────────┬────────┘
         │
         ▼ AJAX (fetch)
┌─────────────────┐
│ WordPress AJAX  │
│ Handler         │
│ - Verify nonce  │
│ - Check perms   │
│ - Get API key   │
└────────┬────────┘
         │
         ▼ wp_remote_post()
┌─────────────────┐
│ OpenAI API      │
│ - Process full  │
│   conversation  │
│ - Generate      │
│   response      │
└────────┬────────┘
         │
         ▼ JSON Response
┌─────────────────┐
│ JavaScript      │
│ 1. Add response │
│ 2. Save to      │
│    localStorage │
│ 3. Render UI    │
└─────────────────┘
```

---

## Security Implementation

### 1. Nonce Protection

```php
// PHP: Create nonce
wp_nonce_field('wp_chatbot_save_key_nonce');

// PHP: Verify nonce
check_admin_referer('wp_chatbot_save_key_nonce');

// JavaScript: Include in AJAX
formData.append('nonce', wpChatbot.nonce);

// PHP AJAX: Verify
check_ajax_referer('chatbot_nonce', 'nonce');
```

**What is a Nonce?**
- "Number used once"
- Time-limited token
- Prevents CSRF (Cross-Site Request Forgery)
- Validates request came from your site

### 2. API Key Security

**NEVER do this (from HTML example):**
```javascript
// BAD - API key visible in browser
const apiKey = document.getElementById('apiKey').value;
fetch('https://api.openai.com/v1/chat/completions', {
    headers: {
        'Authorization': `Bearer ${apiKey}`
    }
});
```

**WordPress Plugin Approach (GOOD):**
```javascript
// API key never leaves server
fetch(wpChatbot.ajaxurl, {
    method: 'POST',
    body: formData  // No API key here
});
```

```php
// Server-side: API key retrieved securely
$api_key = get_option('wp_chatbot_api_key');
$response = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
    'headers' => array(
        'Authorization' => 'Bearer ' . $api_key
    )
));
```

### 3. Permission Checks

```php
// Only administrators can use chatbot
if (!current_user_can('manage_options')) {
    wp_send_json_error(array('message' => 'Unauthorized access'));
    return;
}
```

---

## Comparison: HTML vs WordPress Implementation

### HTML Version (04-chat-with-memory.html)

**Pros:**
- Simple, single file
- No server required
- Easy to test

**Cons:**
- ⚠️ API key exposed in browser (security risk)
- ⚠️ Can be stolen from Network tab
- ⚠️ No user authentication
- ⚠️ localStorage accessible to anyone on device

### WordPress Plugin Version

**Pros:**
- ✅ API key stored server-side
- ✅ User authentication/authorization
- ✅ Nonce-based CSRF protection
- ✅ Can be restricted to admin users
- ✅ Professional, reusable architecture

**Cons:**
- More complex setup
- Requires WordPress environment

---

## CSS Styling: WhatsApp-like Interface

```css
/* Chat Container with Pattern Background */
.chat-container {
    height: 500px;
    overflow-y: auto;
    border: 4px solid #6c757d;
    border-radius: 15px;
    padding: 15px;
    background: #e5ddd5;
    background-image: url('data:image/svg+xml;base64,...');
}

/* User Messages (Right-aligned, Green) */
.message.user {
    background: #dcf8c6;
    color: #303030;
    margin-left: auto;
    align-self: flex-end;
}

/* Assistant Messages (Left-aligned, White) */
.message.assistant {
    background: white;
    color: #303030;
    margin-right: auto;
    align-self: flex-start;
}
```

**Design Principles:**
- **Visual Distinction:** User = green bubble, AI = white bubble
- **Alignment:** User right, AI left (like messaging apps)
- **Scrolling:** Auto-scroll to latest message
- **Loading State:** Visual feedback while waiting

---

## System Prompt Management

### Template File: `admin/includes/inc-system-prompt.php`

```php
You are a helpful assistant. You always answer in a concise manner.

<strong>Brighton Web Development Meet Up Details:</strong>
• Date: October 29th
• Venue: The Skiff
• Time: 6:30 PM - 9:00 PM
```

### How It's Used

```php
// In template file
$system_prompt = '';
$system_prompt_file = WP_CHATBOT_PLUGIN_DIR . 'admin/includes/inc-system-prompt.php';
if (file_exists($system_prompt_file)) {
    ob_start();
    include $system_prompt_file;
    $system_prompt = ob_get_clean();
}
```

```javascript
// Passed to JavaScript
window.wpChatbotSystemPrompt = <?php echo json_encode($system_prompt); ?>;
```

**Benefits:**
- Centralized prompt management
- Can be edited without touching code
- Visible in admin interface
- Consistent across sessions

---

## Advanced Concepts

### 1. Transients for Temporary Storage

```php
// Set transient (expires in 1 hour)
set_transient('wp_chatbot_show_key_' . get_current_user_id(), true, 3600);

// Get transient
$is_visible = get_transient('wp_chatbot_show_key_' . get_current_user_id());

// Delete transient
delete_transient('wp_chatbot_show_key_' . get_current_user_id());
```

**Use Case:** Show/hide API key toggle
- State persists for 1 hour
- User-specific (different users can have different states)
- Auto-expires (security feature)

### 2. WordPress Options API

```php
// Store API key in database
update_option('wp_chatbot_api_key', $api_key);

// Retrieve API key
$api_key = get_option('wp_chatbot_api_key', '');  // Second param = default
```

**Why Use Options?**
- Persistent storage (survives server restarts)
- Easy retrieval
- Automatically serialized/unserialized
- Cached for performance

### 3. Loading States & UX

```javascript
// Add loading message
const loadingDiv = document.createElement('div');
loadingDiv.className = 'message assistant loading';
loadingDiv.textContent = 'Thinking...';
messagesDiv.appendChild(loadingDiv);

// Disable send button (prevent double-sending)
sendBtn.disabled = true;

// After response
messagesDiv.removeChild(loadingDiv);
sendBtn.disabled = false;
```

**Why Important?**
- Provides visual feedback
- Prevents duplicate requests
- Improves perceived performance

---

## Testing the Plugin

### 1. Activation
```
WordPress Admin → Plugins → Activate "07 UDEMY CHATBOT WITH MEMORY"
```

### 2. Configuration
```
Admin Menu → 07 CHATBOT → Enter API Key → Save
```

### 3. Test Conversation
```
User: "Capital of England?"
AI: "London"
User: "What about its population?"
AI: [Knows "it" refers to London because of conversation history]
```

### 4. Test Memory Persistence
```
1. Send a message
2. Refresh the page
3. Previous messages should still be visible (loaded from localStorage)
```

### 5. Test Clear Chat
```
Click "Clear Chat" → Confirm → History should be deleted
```

---

## Common Issues & Solutions

### Issue: "API key not configured"
**Solution:** Check that API key is saved in Settings

### Issue: Chat history not persisting
**Solution:** 
- Check browser localStorage limit
- Ensure JavaScript is not blocked
- Check browser console for errors

### Issue: Messages not sending
**Solution:**
- Verify API key is valid
- Check browser Network tab for AJAX errors
- Ensure nonce is valid (page not stale)

---

## Extension Ideas

1. **User-Specific Storage:** Store chat history per WordPress user in database
2. **Export Chat:** Add button to download conversation as PDF/TXT
3. **Multiple Conversations:** Allow users to have multiple chat threads
4. **Admin Settings:** Make model and max_tokens configurable
5. **Token Usage Tracking:** Log and display API usage costs
6. ~~**Shortcode Support:** Allow chatbot on frontend pages~~ ✅ **IMPLEMENTED**
7. **Streaming Responses:** Implement SSE for real-time token streaming

---

## Frontend Shortcode Implementation

### Overview

The plugin includes a powerful shortcode `[wp_chatbot]` that allows you to embed the chatbot on any WordPress page or post. This brings the conversational AI experience from the admin area to your frontend, making it accessible to site visitors.

### File Structure

```
07-wp-chatbot/
└── shortcodes/
    ├── chatbot-shortcode.php          # Shortcode registration and handler
    └── assets/
        ├── css/
        │   └── frontend-styles.css    # Frontend-specific styling
        └── js/
            └── frontend-chatbot.js    # Frontend JavaScript logic
```

---

### Usage

#### Basic Usage

Simply add the shortcode to any page or post:

```
[wp_chatbot]
```

The chatbot will use the API key configured in the admin settings.

#### Advanced Usage with Custom API Key

You can override the default API key using the `api_key` attribute:

```
[wp_chatbot api_key="sk-your-custom-key-here"]
```

**Use Cases:**
- Different API keys for different pages
- Separate billing for specific client projects
- Testing with a sandbox API key

---

### Code Breakdown

#### 1. Shortcode Registration: `chatbot-shortcode.php`

```php
// Register the shortcode
add_shortcode('wp_chatbot', 'wp_chatbot_shortcode');
```

**How WordPress Shortcodes Work:**
1. User adds `[wp_chatbot]` to page content
2. WordPress parses content and finds the shortcode
3. Calls the registered function `wp_chatbot_shortcode()`
4. Function returns HTML that replaces the shortcode
5. HTML is rendered on the frontend

---

#### 2. Shortcode Handler Function

```php
function wp_chatbot_shortcode($atts) {
    // Parse shortcode attributes
    $atts = shortcode_atts(
        array(
            'api_key' => '', // Optional: Override the default API key
        ),
        $atts,
        'wp_chatbot'
    );
    
    // Check if API key is configured (use shortcode attribute or global setting)
    $api_key = !empty($atts['api_key']) ? $atts['api_key'] : get_option('wp_chatbot_api_key', '');
    
    // Include system prompt
    $system_prompt = '';
    $system_prompt_file = WP_CHATBOT_PLUGIN_DIR . 'admin/includes/inc-system-prompt.php';
    if (file_exists($system_prompt_file)) {
        ob_start();
        include $system_prompt_file;
        $system_prompt = ob_get_clean();
    }
    
    // Start output buffering
    ob_start();
    ?>
    
    <!-- HTML template here -->
    
    <?php
    return ob_get_clean();
}
```

**Key Concepts:**

**1. `shortcode_atts()`**
- Merges user-provided attributes with defaults
- Ensures all expected attributes exist
- Sanitizes attribute names

**Example:**
```php
// User writes: [wp_chatbot api_key="abc123"]
// Result: $atts = ['api_key' => 'abc123']

// User writes: [wp_chatbot]
// Result: $atts = ['api_key' => '']
```

**2. API Key Priority**
```php
$api_key = !empty($atts['api_key']) ? $atts['api_key'] : get_option('wp_chatbot_api_key', '');
```
- First checks shortcode attribute: `[wp_chatbot api_key="..."]`
- Falls back to admin settings: `get_option()`
- Allows flexibility per page

**3. Output Buffering**
```php
ob_start();
?>
<!-- HTML here -->
<?php
return ob_get_clean();
```

**Why?** Shortcodes must **return** HTML, not echo it. Output buffering captures the HTML and returns it as a string.

---

#### 3. HTML Template Structure

```php
<div class="wp-chatbot-frontend-wrapper">
    
    <?php if (empty($api_key)): ?>
        <!-- Error: No API key configured -->
        <div class="wp-chatbot-notice wp-chatbot-error">
            <p><?php _e('ChatBot is not configured. Please contact the site administrator.', 'wp-chatbot'); ?></p>
        </div>
    <?php else: ?>
        
        <!-- Chatbot Interface -->
        <div class="wp-chatbot-container">
            <div class="wp-chatbot-header">
                <h3><?php _e('ChatBot with Memory', 'wp-chatbot'); ?></h3>
                <p><?php _e('This chatbot maintains conversation history...', 'wp-chatbot'); ?></p>
            </div>

            <!-- Messages area -->
            <div id="wp-chatbot-chat-container" class="wp-chatbot-chat-container">
                <div id="wp-chatbot-messages" class="wp-chatbot-messages-area"></div>
            </div>

            <!-- Input area -->
            <div id="wp-chatbot-input-container" class="wp-chatbot-input-container">
                <input type="text" id="wp-chatbot-message-input" class="wp-chatbot-input" 
                       placeholder="<?php _e('Type your message...', 'wp-chatbot'); ?>">
                <button id="wp-chatbot-send-btn" class="wp-chatbot-button wp-chatbot-button-primary">
                    <?php _e('Send', 'wp-chatbot'); ?>
                </button>
                <button id="wp-chatbot-clear-btn" class="wp-chatbot-button wp-chatbot-button-secondary">
                    <?php _e('Clear Chat', 'wp-chatbot'); ?>
                </button>
            </div>
        </div>
        
    <?php endif; ?>
    
    <!-- Pass data to JavaScript -->
    <script type="text/javascript">
        window.wpChatbotFrontendSystemPrompt = <?php echo json_encode($system_prompt); ?>;
        window.wpChatbotFrontendCustomApiKey = <?php echo json_encode(!empty($atts['api_key']) ? $atts['api_key'] : ''); ?>;
    </script>
</div>
```

**Design Decisions:**

1. **Graceful Degradation:** Shows error message if API key is missing
2. **Translation Ready:** Uses `_e()` for internationalization
3. **Unique IDs:** Frontend uses different IDs than admin (prevents conflicts)
4. **Data Passing:** Uses `window` variables to pass PHP data to JavaScript

---

#### 4. Conditional Asset Loading

```php
function wp_chatbot_enqueue_frontend_assets() {
    global $post;
    
    // Only enqueue if the shortcode is present on the page
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'wp_chatbot')) {
        
        // Enqueue CSS
        wp_enqueue_style(
            'wp-chatbot-frontend-styles',
            WP_CHATBOT_PLUGIN_URL . 'shortcodes/assets/css/frontend-styles.css',
            array(),
            WP_CHATBOT_VERSION
        );
        
        // Enqueue JavaScript
        wp_enqueue_script(
            'wp-chatbot-frontend-script',
            WP_CHATBOT_PLUGIN_URL . 'shortcodes/assets/js/frontend-chatbot.js',
            array(),
            WP_CHATBOT_VERSION,
            true
        );
        
        // Pass AJAX data to JavaScript
        wp_localize_script(
            'wp-chatbot-frontend-script',
            'wpChatbotFrontend',
            array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('wp_chatbot_nonce')
            )
        );
    }
}
add_action('wp_enqueue_scripts', 'wp_chatbot_enqueue_frontend_assets');
```

**Performance Optimization:**

**Problem:** Loading CSS/JS on every page is wasteful if the shortcode isn't present.

**Solution:** `has_shortcode()` checks if shortcode exists on the current page.

```php
// Good: Only loads on pages with [wp_chatbot]
if (has_shortcode($post->post_content, 'wp_chatbot')) {
    wp_enqueue_style(...);
}

// Bad: Loads on every page (unnecessary)
wp_enqueue_style(...);
```

**Benefits:**
- ✅ Faster page loads (fewer HTTP requests)
- ✅ Smaller page size
- ✅ Better performance scores

---

#### 5. Frontend JavaScript: `frontend-chatbot.js`

##### Message Storage with Unique Key

```javascript
// Uses different localStorage key than admin version
function loadMessages() {
    const saved = localStorage.getItem('wp_chatbot_frontend_history');
    if (saved) {
        messages = JSON.parse(saved);
    }
    renderMessages();
}

function saveMessages() {
    localStorage.setItem('wp_chatbot_frontend_history', JSON.stringify(messages));
}
```

**Why Different Key?**
- Admin uses: `wp_chatbot_history`
- Frontend uses: `wp_chatbot_frontend_history`
- Keeps conversations separate
- Admin chat doesn't mix with frontend chat

##### Custom API Key Support

```javascript
// Create FormData for AJAX request
const formData = new FormData();
formData.append('action', 'chatbot_send_message');
formData.append('nonce', wpChatbotFrontend.nonce);
formData.append('messages', JSON.stringify(messages));

// Add custom API key if provided via shortcode
if (window.wpChatbotFrontendCustomApiKey) {
    formData.append('custom_api_key', window.wpChatbotFrontendCustomApiKey);
}
```

**Flow:**
1. Shortcode renders: `[wp_chatbot api_key="xyz"]`
2. PHP passes to JavaScript: `window.wpChatbotFrontendCustomApiKey = "xyz"`
3. JavaScript sends to AJAX handler: `formData.append('custom_api_key', 'xyz')`
4. PHP handler uses custom key if provided

##### System Prompt Fallback

```javascript
const systemPrompt = window.wpChatbotFrontendSystemPrompt || `
    You are a helpful assistant. You always answer in a concise manner.
    // ... fallback prompt ...
`;
```

**Why?**
- If PHP system prompt file is missing
- JavaScript uses built-in default
- Chatbot still functions

---

#### 6. Frontend CSS Styling

Key styling differences from admin version:

```css
/* Responsive wrapper */
.wp-chatbot-frontend-wrapper {
    max-width: 900px;
    margin: 20px auto;
}

/* Clean, modern container */
.wp-chatbot-container {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.04);
}

/* Prominent header */
.wp-chatbot-header h3 {
    border-bottom: 2px solid #2271b1;
    padding-bottom: 10px;
}

/* User guidance */
.wp-chatbot-header p {
    background: #e7f3ff;
    border-left: 4px solid #2271b1;
    padding: 12px;
}

/* Error notice styling */
.wp-chatbot-error {
    background: #fcf2f2;
    border-left: 4px solid #dc3232;
    color: #721c24;
}
```

**Mobile Responsive:**

```css
@media (max-width: 782px) {
    .wp-chatbot-message {
        max-width: 85%; /* Larger on mobile */
    }
    
    .wp-chatbot-input-container {
        flex-wrap: wrap; /* Stack on small screens */
    }
    
    .wp-chatbot-input {
        min-width: 100%; /* Full width input */
    }
}

@media (max-width: 480px) {
    .wp-chatbot-chat-container {
        height: 400px; /* Shorter on phones */
    }
}
```

---

### Key Features of the Shortcode

#### 1. **Seamless Integration**
- Works on any page or post
- Compatible with page builders (Elementor, Gutenberg, etc.)
- No configuration required (uses admin settings)

#### 2. **Custom API Key Override**
```
[wp_chatbot api_key="sk-proj-custom-key"]
```
Allows per-page API key customization.

#### 3. **Shared System Prompt**
- Uses same system prompt as admin version
- Consistent behavior across admin and frontend
- Single source of truth

#### 4. **Separate Conversation History**
- Frontend chat stored in: `wp_chatbot_frontend_history`
- Admin chat stored in: `wp_chatbot_history`
- No cross-contamination

#### 5. **Error Handling**
- Shows user-friendly message if API key is missing
- Doesn't break the page
- Guides users to contact administrator

#### 6. **Performance Optimized**
- Only loads assets on pages with shortcode
- Conditional script/style enqueuing
- Minimal performance impact

---

### Admin vs Frontend: Key Differences

| Feature | Admin Version | Frontend Shortcode |
|---------|--------------|-------------------|
| **Access** | Admin-only (`manage_options`) | Public (any visitor) |
| **Location** | Admin menu page | Any page/post |
| **localStorage Key** | `wp_chatbot_history` | `wp_chatbot_frontend_history` |
| **Element IDs** | Generic (`messages`, `send-btn`) | Prefixed (`wp-chatbot-messages`, `wp-chatbot-send-btn`) |
| **Asset Loading** | Always on admin page | Conditional (only if shortcode present) |
| **API Key Source** | Always from admin settings | Admin settings OR shortcode attribute |
| **Styling** | Admin-specific (admin-styles.css) | Frontend-specific (frontend-styles.css) |
| **Use Case** | Testing, internal use | Customer-facing, public chatbot |

---

### Usage Examples

#### Example 1: Basic Customer Support Page

**Page Title:** "Chat with Us"

**Content:**
```
Welcome to our customer support chatbot! Ask me anything about our products or services.

[wp_chatbot]
```

**Result:** Chatbot appears using the default API key from admin settings.

---

#### Example 2: Product-Specific Chatbot

**Page Title:** "Cordless Tools Expert"

**Content:**
```
Have questions about our cordless tool range? Our AI expert is here to help!

[wp_chatbot]
```

**Custom System Prompt:** Edit `admin/includes/inc-system-prompt.php` to focus on cordless tools:
```php
You are an expert in cordless power tools. You provide detailed information 
about battery life, power ratings, and product comparisons. You always 
recommend products from our catalog.

Our Products:
- Cordless Drill 20V (Model CD-2000)
- Cordless Vacuum Cleaner (Model CV-400)
- Cordless Angle Grinder (Model AG-150)
```

---

#### Example 3: Different API Keys for Different Departments

**Sales Page:**
```
[wp_chatbot api_key="sk-proj-sales-team-key"]
```

**Support Page:**
```
[wp_chatbot api_key="sk-proj-support-team-key"]
```

**Benefits:**
- Separate billing per department
- Different usage limits
- Track costs separately

---

#### Example 4: With Page Builder (Elementor)

1. Add a "Shortcode" widget to the page
2. Enter: `[wp_chatbot]`
3. Style the container with Elementor's styling options
4. The chatbot integrates seamlessly

---

### Technical Implementation Details

#### How the Shortcode Communicates with the Backend

```
┌─────────────────────────┐
│  User on Frontend Page  │
│  Types: "Hello"         │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│  frontend-chatbot.js    │
│  - Adds to messages[]   │
│  - Prepares FormData    │
└───────────┬─────────────┘
            │
            ▼ fetch()
┌─────────────────────────┐
│  admin-ajax.php         │
│  WordPress AJAX Router  │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│  chatbot-api-handler.php│
│  - Verifies nonce       │
│  - Gets API key         │
│  - Calls OpenAI         │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│  OpenAI API             │
│  Returns response       │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│  frontend-chatbot.js    │
│  - Adds to messages[]   │
│  - Renders in chat      │
└─────────────────────────┘
```

**Key Point:** The same AJAX handler (`chatbot-api-handler.php`) serves both admin and frontend versions. The only difference is the nonce check passes for any logged-in user with `manage_options` capability.

---

#### Custom API Key Handling in AJAX Handler

The AJAX handler needs to be updated to support custom API keys from the shortcode:

```php
// In chatbot-api-handler.php
function wp_chatbot_send_message() {
    check_ajax_referer('chatbot_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(array('message' => 'Unauthorized access'));
        return;
    }
    
    // Check for custom API key from shortcode
    $api_key = '';
    if (isset($_POST['custom_api_key']) && !empty($_POST['custom_api_key'])) {
        $api_key = sanitize_text_field($_POST['custom_api_key']);
    } else {
        // Fall back to admin settings
        $api_key = get_option('wp_chatbot_api_key', '');
    }
    
    if (empty($api_key)) {
        wp_send_json_error(array('message' => 'API key not configured'));
        return;
    }
    
    // Continue with OpenAI request...
}
```

**Security Note:** Even with custom API keys, the key is still sent from JavaScript to PHP via AJAX, never exposed directly to the browser's API calls to OpenAI.

---

### Security Considerations

#### 1. **No Public API Key Exposure**
```javascript
// NEVER do this on frontend (BAD):
fetch('https://api.openai.com/v1/chat/completions', {
    headers: {
        'Authorization': `Bearer ${apiKey}` // API key visible in Network tab!
    }
});

// Always do this (GOOD):
fetch(wpChatbotFrontend.ajaxurl, {
    method: 'POST',
    body: formData // API key stays on server
});
```

#### 2. **Nonce Validation**
```php
check_ajax_referer('chatbot_nonce', 'nonce');
```
Prevents unauthorized requests.

#### 3. **Capability Check**
```php
if (!current_user_can('manage_options')) {
    wp_send_json_error(array('message' => 'Unauthorized access'));
}
```

**Important:** Current implementation requires admin capabilities. For public chatbots, you might want to:

```php
// Allow any logged-in user
if (!is_user_logged_in()) {
    wp_send_json_error(array('message' => 'Please log in'));
}

// Or allow everyone (careful with costs!)
// Remove the capability check entirely
```

#### 4. **Sanitization**
```php
$api_key = sanitize_text_field($_POST['custom_api_key']);
```
Always sanitize user input.

---

### Common Issues & Solutions

#### Issue 1: Shortcode Shows as Text

**Symptom:**
```
[wp_chatbot]
```
appears on the page instead of rendering the chatbot.

**Cause:** Shortcode not registered.

**Solution:** Ensure `chatbot-shortcode.php` is included in main plugin file:
```php
// In wp-chatbot.php
require_once WP_CHATBOT_PLUGIN_DIR . 'shortcodes/chatbot-shortcode.php';
```

---

#### Issue 2: "ChatBot is not configured" Error

**Symptom:** Red error message on frontend.

**Cause:** No API key set in admin settings.

**Solution:**
1. Go to WordPress Admin → 07 CHATBOT
2. Enter your OpenAI API key
3. Click "Save API Key"

---

#### Issue 3: Styles Not Loading

**Symptom:** Chatbot appears unstyled (no colors, no layout).

**Cause:** CSS file not found or enqueue condition failing.

**Debug:**
```php
// Add to shortcode handler
error_log('Enqueuing assets for shortcode');
error_log('CSS URL: ' . WP_CHATBOT_PLUGIN_URL . 'shortcodes/assets/css/frontend-styles.css');
```

**Check:**
- File exists: `07-wp-chatbot/shortcodes/assets/css/frontend-styles.css`
- `WP_CHATBOT_PLUGIN_URL` constant is defined
- `has_shortcode()` condition is working

---

#### Issue 4: AJAX Returns "Unauthorized access"

**Symptom:** Messages don't send, console shows error.

**Cause:** User doesn't have `manage_options` capability.

**Solution:** Modify capability check in `chatbot-api-handler.php`:
```php
// Allow any logged-in user
if (!is_user_logged_in()) {
    wp_send_json_error(array('message' => 'Please log in to use the chatbot'));
    return;
}

// OR allow everyone (removes requirement entirely)
// Comment out the capability check
```

---

#### Issue 5: Messages Not Persisting

**Symptom:** Chat history clears on page refresh.

**Cause:** localStorage blocked or JavaScript error.

**Debug:**
```javascript
// Add to frontend-chatbot.js
console.log('Saving messages:', messages);
console.log('localStorage available:', typeof Storage !== 'undefined');
```

**Solutions:**
- Check browser localStorage is enabled
- Check browser console for JavaScript errors
- Clear browser cache and try again

---

### Enhancement Ideas for Shortcode

#### 1. **Configurable Parameters**
```php
$atts = shortcode_atts(
    array(
        'api_key' => '',
        'height' => '500px',    // Custom chat height
        'title' => 'ChatBot',   // Custom title
        'model' => 'gpt-4o-mini', // OpenAI model
        'max_tokens' => 1024,   // Response length
        'theme' => 'default'    // Color theme
    ),
    $atts,
    'wp_chatbot'
);
```

**Usage:**
```
[wp_chatbot height="600px" title="Support Assistant" model="gpt-4"]
```

#### 2. **Guest Access Without Login**
```php
// In AJAX handler - create guest session
if (!is_user_logged_in()) {
    // Implement rate limiting for guests
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $rate_limit = get_transient('chatbot_rate_' . $ip_address);
    
    if ($rate_limit && $rate_limit > 10) {
        wp_send_json_error(array('message' => 'Rate limit exceeded'));
        return;
    }
    
    set_transient('chatbot_rate_' . $ip_address, ($rate_limit + 1), 3600);
}
```

#### 3. **Multiple Language Support**
```
[wp_chatbot language="es"]
```

```php
// Load language-specific system prompt
$system_prompt_file = WP_CHATBOT_PLUGIN_DIR . "admin/includes/inc-system-prompt-{$atts['language']}.php";
```

#### 4. **Conversation Export**
```javascript
// Add export button
exportBtn.addEventListener('click', function() {
    const text = messages.map(m => `${m.role}: ${m.content}`).join('\n\n');
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'chatbot-conversation.txt';
    a.click();
});
```

#### 5. **Analytics Integration**
```php
// Track chatbot usage
function log_chatbot_message($user_id, $message, $response) {
    global $wpdb;
    $wpdb->insert(
        $wpdb->prefix . 'chatbot_logs',
        array(
            'user_id' => $user_id,
            'message' => $message,
            'response' => $response,
            'timestamp' => current_time('mysql')
        )
    );
}
```

---

## Conclusion

This plugin demonstrates:

✅ **Secure API Integration:** Server-side key management  
✅ **Conversation Memory:** localStorage + full history in API calls  
✅ **WordPress Best Practices:** Hooks, nonces, options API  
✅ **Professional UX:** Loading states, error handling, clean UI  
✅ **Extensible Architecture:** Organized folder structure for growth

The key difference from the HTML example is **security** - by proxying API requests through WordPress, we protect the API key while maintaining the same conversational experience.
