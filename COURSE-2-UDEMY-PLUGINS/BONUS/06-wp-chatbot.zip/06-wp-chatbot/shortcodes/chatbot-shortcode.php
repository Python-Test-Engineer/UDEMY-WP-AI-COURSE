<?php
/**
 * ChatBot Shortcode Handler
 * 
 * Provides shortcode functionality to display the chatbot on the frontend
 * Usage: [wp_chatbot]
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Render the ChatBot shortcode
 * 
 * @param array $atts Shortcode attributes
 * @return string HTML output for the chatbot
 */
function wp_chatbot_shortcode($atts) {
    // Parse shortcode attributes
    $atts = shortcode_atts(
        array(
            'api_key' => '', // Optional: Override the default API key
        ),
        $atts,
        'wp_chatbot'
    );
    
    // Check if API key is configured (use shortcode attribute or global setting)
    $api_key = !empty($atts['api_key']) ? $atts['api_key'] : get_option('wp_chatbot_api_key', '');
    
    // Include system prompt
    $system_prompt = '';
    $system_prompt_file = WP_CHATBOT_PLUGIN_DIR . 'admin/includes/inc-system-prompt.php';
    if (file_exists($system_prompt_file)) {
        ob_start();
        include $system_prompt_file;
        $system_prompt = ob_get_clean();
    }
    
    // Start output buffering
    ob_start();
    ?>
    
    <div class="wp-chatbot-frontend-wrapper">
        
        <?php if (empty($api_key)): ?>
            <div class="wp-chatbot-notice wp-chatbot-error">
                <p><?php _e('ChatBot is not configured. Please contact the site administrator.', 'wp-chatbot'); ?></p>
            </div>
        <?php else: ?>
            
            <div class="wp-chatbot-container">
                <div class="wp-chatbot-header">
                    <h3><?php _e('ChatBot with Memory', 'wp-chatbot'); ?></h3>
                    <p><?php _e('This chatbot maintains conversation history. Your conversation will persist across page refreshes.', 'wp-chatbot'); ?></p>
                </div>

                <div id="wp-chatbot-chat-container" class="wp-chatbot-chat-container">
                    <div id="wp-chatbot-messages" class="wp-chatbot-messages-area"></div>
                </div>

                <div id="wp-chatbot-input-container" class="wp-chatbot-input-container">
                    <input type="text" id="wp-chatbot-message-input" value="Tell me about FOAM products?" class="wp-chatbot-input" placeholder="<?php _e('Type your message...', 'wp-chatbot'); ?>" value="">
                    <button id="wp-chatbot-send-btn" class="wp-chatbot-button wp-chatbot-button-primary"><?php _e('Send', 'wp-chatbot'); ?></button>
                    <button id="wp-chatbot-clear-btn" class="wp-chatbot-button wp-chatbot-button-secondary"><?php _e('Clear Chat', 'wp-chatbot'); ?></button>
                </div>
            </div>
            
        <?php endif; ?>
        
        <!-- Hidden data for JavaScript -->
        <script type="text/javascript">
            // Pass system prompt and custom API key to JavaScript
            window.wpChatbotFrontendSystemPrompt = <?php echo json_encode($system_prompt); ?>;
            window.wpChatbotFrontendCustomApiKey = <?php echo json_encode(!empty($atts['api_key']) ? $atts['api_key'] : ''); ?>;
        </script>
    </div>
    
    <?php
    
    return ob_get_clean();
}

// Register the shortcode
add_shortcode('wp_chatbot', 'wp_chatbot_shortcode');

/**
 * Enqueue frontend assets for the chatbot shortcode
 */
function wp_chatbot_enqueue_frontend_assets() {
    // Only enqueue if we're on a page/post that has the shortcode
    global $post;
    
    if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'wp_chatbot')) {
        // Enqueue frontend CSS
        wp_enqueue_style(
            'wp-chatbot-frontend-styles',
            WP_CHATBOT_PLUGIN_URL . 'shortcodes/assets/css/frontend-styles.css',
            array(),
            WP_CHATBOT_VERSION
        );
        
        // Enqueue frontend JavaScript
        wp_enqueue_script(
            'wp-chatbot-frontend-script',
            WP_CHATBOT_PLUGIN_URL . 'shortcodes/assets/js/frontend-chatbot.js',
            array(),
            WP_CHATBOT_VERSION,
            true
        );
        
        // Localize script with AJAX URL and nonce
        wp_localize_script(
            'wp-chatbot-frontend-script',
            'wpChatbotFrontend',
            array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('wp_chatbot_nonce')
            )
        );
    }
}
add_action('wp_enqueue_scripts', 'wp_chatbot_enqueue_frontend_assets');
