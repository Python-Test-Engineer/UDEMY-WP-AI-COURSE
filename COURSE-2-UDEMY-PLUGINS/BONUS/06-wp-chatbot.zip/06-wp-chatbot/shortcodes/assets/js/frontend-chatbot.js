// ChatBot Frontend - JavaScript
document.addEventListener('DOMContentLoaded', function () {
    
    // Get system prompt from PHP
    const systemPrompt = window.wpChatbotFrontendSystemPrompt || `
        You are a helpful assistant. You always answer in a concise manner.

        You never refuse to answer but do not make things up - just say 'I don't know'. 
        You always try to help the user as much as possible.

        Convert markdown to HTML when needed so that output is properly formatted.
        Ensure there is a new line after each sentence.

        Brighton Web Development Meet Up is taking place on October 29th.
        The venue is the Skiff.
        The event starts at 6:30 PM and finishes at 9:00 PM.
        The Speaker is Craig West and the topic is 'AI Agents and Evals for all languages'
        Brighton Web Development Meet Up is part of Silicon Brighton.
        The current organiser is Gavin and it has been running since 1865 (3rd October 1865) 
        the first meetup being organised by Louise.
        Similar meet ups are WordUp Brighton, BrightonPy, PHP Sussex and many more.
        Details at siliconbrighton.com.
    `;

    // Initialize messages array with system prompt
    let messages = [{ role: 'system', content: systemPrompt }];

    // DOM elements
    const messagesDiv = document.getElementById('wp-chatbot-messages');
    const messageInput = document.getElementById('wp-chatbot-message-input');
    const sendBtn = document.getElementById('wp-chatbot-send-btn');
    const clearBtn = document.getElementById('wp-chatbot-clear-btn');
    const chatContainer = document.getElementById('wp-chatbot-chat-container');

    // Check if elements exist (shortcode might not be on page)
    if (!messagesDiv || !messageInput || !sendBtn || !clearBtn || !chatContainer) {
        return;
    }

    // Load messages from localStorage
    function loadMessages() {
        const saved = localStorage.getItem('wp_chatbot_frontend_history');
        if (saved) {
            try {
                messages = JSON.parse(saved);
                // Ensure system prompt is at the start
                if (!messages[0] || messages[0].role !== 'system') {
                    messages.unshift({ role: 'system', content: systemPrompt });
                }
            } catch (e) {
                console.error('Error loading chat history:', e);
                messages = [{ role: 'system', content: systemPrompt }];
            }
        }
        renderMessages();
    }

    // Save messages to localStorage
    function saveMessages() {
        try {
            localStorage.setItem('wp_chatbot_frontend_history', JSON.stringify(messages));
        } catch (e) {
            console.error('Error saving chat history:', e);
        }
    }

    // Render messages to the chat
    function renderMessages() {
        messagesDiv.innerHTML = '';
        // Skip system message (index 0) when rendering
        messages.slice(1).forEach(msg => {
            const msgDiv = document.createElement('div');
            msgDiv.className = `wp-chatbot-message ${msg.role}`;
            msgDiv.innerHTML = msg.content; // Use innerHTML to support HTML formatting
            messagesDiv.appendChild(msgDiv);
        });
        scrollToBottom();
    }

    // Scroll chat to bottom
    function scrollToBottom() {
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }

    // Send message to OpenAI via WordPress AJAX
    async function sendMessage(userMessage) {
        if (!userMessage.trim()) {
            return;
        }

        // Add user message
        messages.push({ role: 'user', content: userMessage });
        saveMessages();
        renderMessages();

        // Clear input
        messageInput.value = '';

        // Add loading message
        const loadingDiv = document.createElement('div');
        loadingDiv.className = 'wp-chatbot-message assistant loading';
        loadingDiv.textContent = 'Thinking...';
        messagesDiv.appendChild(loadingDiv);
        scrollToBottom();

        // Disable send button
        sendBtn.disabled = true;

        // Log conversation history being sent
        console.log('Sending to OpenAI - Total messages in conversation:', messages.length);
        console.log('Full conversation history:', messages);

        try {
            // Create FormData for AJAX request
            const formData = new FormData();
            formData.append('action', 'chatbot_send_message');
            formData.append('nonce', wpChatbotFrontend.nonce);
            formData.append('messages', JSON.stringify(messages));
            
            // Add custom API key if provided via shortcode
            if (window.wpChatbotFrontendCustomApiKey) {
                formData.append('custom_api_key', window.wpChatbotFrontendCustomApiKey);
            }

            // Send request to WordPress AJAX handler
            const response = await fetch(wpChatbotFrontend.ajaxurl, {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            // Remove loading message
            messagesDiv.removeChild(loadingDiv);

            if (data.success) {
                // Add assistant response
                const assistantMessage = data.data.message;
                messages.push({ role: 'assistant', content: assistantMessage });
                saveMessages();
                renderMessages();

                console.log('Assistant response added. Total messages now:', messages.length);
            } else {
                // Show error message
                const errorDiv = document.createElement('div');
                errorDiv.className = 'wp-chatbot-message assistant';
                errorDiv.style.backgroundColor = '#f8d7da';
                errorDiv.style.color = '#721c24';
                errorDiv.textContent = 'Error: ' + (data.data && data.data.message ? data.data.message : 'Unknown error occurred');
                messagesDiv.appendChild(errorDiv);
                scrollToBottom();
            }
        } catch (error) {
            // Remove loading message if it exists
            if (loadingDiv.parentNode) {
                messagesDiv.removeChild(loadingDiv);
            }

            // Show error message
            const errorDiv = document.createElement('div');
            errorDiv.className = 'wp-chatbot-message assistant';
            errorDiv.style.backgroundColor = '#f8d7da';
            errorDiv.style.color = '#721c24';
            errorDiv.textContent = 'Error: ' + error.message;
            messagesDiv.appendChild(errorDiv);
            scrollToBottom();

            console.error('Error sending message:', error);
        } finally {
            // Re-enable send button
            sendBtn.disabled = false;
        }
    }

    // Event listener for send button
    sendBtn.addEventListener('click', function () {
        const message = messageInput.value.trim();
        if (message) {
            sendMessage(message);
        }
    });

    // Allow enter key to send
    messageInput.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            const message = messageInput.value.trim();
            if (message) {
                sendMessage(message);
            }
        }
    });

    // Clear chat functionality
    clearBtn.addEventListener('click', function () {
        if (confirm('Are you sure you want to clear the chat history?')) {
            messages = [{ role: 'system', content: systemPrompt }];
            saveMessages();
            renderMessages();
            console.log('Chat history cleared');
        }
    });

    // Load messages on page load
    loadMessages();

    // Debug: Log initial state
    console.log('ChatBot Frontend initialized. Messages array:', messages);
});
