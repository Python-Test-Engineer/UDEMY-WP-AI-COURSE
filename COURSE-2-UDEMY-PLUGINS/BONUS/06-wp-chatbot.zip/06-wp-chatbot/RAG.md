CONTEXT: Current folder and functions\chatbot-api-handler.php most likely the main page but you decide.


https://mydigitalagent.co.uk/udemy/wp-json/hybrid-search/v1/search?query is the REST API that gives the following JSON response to a 'query':


response = 
{
  "query": "cordless tools",
  "context": "Vacuum Cleaner Cordless Stick\nPowerful cordless cleaning with up to 40 minutes of fade-free runtime. Converts to handheld vacuum for furniture, stairs, and car interior. LED headlights illuminate hidden dust and debris. HEPA filtration .",
  "fts_post_ids": [
    168
  ],
  "semantic_post_ids": [
    168,
    187,
    155
  ]
}

with response.context being the text RAG that specific to the query.

GOAL: For a given user query 'Tell me about FOAM products?' , get the relevant 'context' and add to the messages so that the agent can answer the domain specific questions.