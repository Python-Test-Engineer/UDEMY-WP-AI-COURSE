// ChatBot with Memory - JavaScript
document.addEventListener('DOMContentLoaded', function () {

    // Get system prompt from PHP
    const systemPrompt = window.wpChatbotSystemPrompt || `
        You are a helpful assistant. You always answer in a concise manner.

        You never refuse to answer but do not make things up - just say 'I don't know'.
        You always try to help the user as much as possible.

        Convert markdown to HTML when needed so that output is properly formatted.
        Ensure there is a new line after each sentence.
    `;

    // Initialize messages array with system prompt
    let messages = [{ role: 'system', content: systemPrompt }];

    // Debug helper functions
    function updateDebugInfo(section, content) {
        const debugDiv = document.getElementById(`debug-${section}-details`);
        if (debugDiv) {
            const timestamp = new Date().toLocaleTimeString();
            debugDiv.innerHTML = `<div class="debug-entry"><strong>[${timestamp}]</strong> ${content}</div>` + debugDiv.innerHTML;
        }
    }

    function clearDebugInfo() {
        ['query', 'api', 'rag', 'response'].forEach(section => {
            const debugDiv = document.getElementById(`debug-${section}-details`);
            if (debugDiv) {
                debugDiv.innerHTML = '';
            }
        });
    }

    function toggleDebugSections() {
        const sections = document.querySelectorAll('.debug-section');
        sections.forEach(section => {
            section.style.display = section.style.display === 'none' ? 'block' : 'none';
        });
    }

    // DOM elements
    const messagesDiv = document.getElementById('messages');
    const messageInput = document.getElementById('messageInput');
    const sendBtn = document.getElementById('sendBtn');
    const clearBtn = document.getElementById('clearBtn');
    const chatContainer = document.getElementById('chatContainer');

    // Load messages from localStorage
    function loadMessages() {
        const saved = localStorage.getItem('wp_chatbot_history');
        if (saved) {
            try {
                messages = JSON.parse(saved);
                // Ensure system prompt is at the start
                if (!messages[0] || messages[0].role !== 'system') {
                    messages.unshift({ role: 'system', content: systemPrompt });
                }
            } catch (e) {
                console.error('Error loading chat history:', e);
                messages = [{ role: 'system', content: systemPrompt }];
            }
        }
        renderMessages();
    }

    // Save messages to localStorage
    function saveMessages() {
        try {
            localStorage.setItem('wp_chatbot_history', JSON.stringify(messages));
        } catch (e) {
            console.error('Error saving chat history:', e);
        }
    }

    // Render messages to the chat
    function renderMessages() {
        messagesDiv.innerHTML = '';
        // Skip system message (index 0) when rendering
        messages.slice(1).forEach(msg => {
            const msgDiv = document.createElement('div');
            msgDiv.className = `message ${msg.role}`;
            msgDiv.innerHTML = msg.content; // Use innerHTML to support HTML formatting
            messagesDiv.appendChild(msgDiv);
        });
        scrollToBottom();
    }

    // Scroll chat to bottom
    function scrollToBottom() {
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }

    // Send message to OpenAI via WordPress AJAX
    async function sendMessage(userMessage) {
        if (!userMessage.trim()) {
            return;
        }

        // DEBUG: Query Processing
        updateDebugInfo('query', `User message received: "${userMessage}" (length: ${userMessage.length})`);
        updateDebugInfo('query', `Current conversation length: ${messages.length} messages`);
        updateDebugInfo('query', `System prompt length: ${systemPrompt.length} characters`);

        // Add user message
        messages.push({ role: 'user', content: userMessage });
        saveMessages();
        renderMessages();

        // Clear input
        messageInput.value = '';

        // DEBUG: API Request Setup
        updateDebugInfo('api', `Preparing AJAX request to WordPress endpoint: ${wpChatbot.ajaxurl}`);
        updateDebugInfo('api', `Using nonce: ${wpChatbot.nonce.substring(0, 10)}...`);
        updateDebugInfo('api', `Sending ${messages.length} messages in conversation history`);

        // Add loading message
        const loadingDiv = document.createElement('div');
        loadingDiv.className = 'message assistant loading';
        loadingDiv.textContent = 'Thinking...';
        messagesDiv.appendChild(loadingDiv);
        scrollToBottom();

        // Disable send button
        sendBtn.disabled = true;

        // DEBUG: Pre-flight checks
        updateDebugInfo('api', `Checking WordPress AJAX endpoint availability...`);
        const startTime = Date.now();

        try {
            // Create FormData for AJAX request
            const formData = new FormData();
            formData.append('action', 'chatbot_send_message');
            formData.append('nonce', wpChatbot.nonce);
            formData.append('messages', JSON.stringify(messages));

            updateDebugInfo('api', `FormData created with action, nonce, and messages payload`);
            updateDebugInfo('api', `Messages payload size: ${JSON.stringify(messages).length} characters`);

            // Send request to WordPress AJAX handler
            updateDebugInfo('api', `Initiating fetch request to WordPress AJAX handler...`);
            const response = await fetch(wpChatbot.ajaxurl, {
                method: 'POST',
                body: formData
            });

            const fetchTime = Date.now() - startTime;
            updateDebugInfo('api', `AJAX request completed in ${fetchTime}ms`);
            updateDebugInfo('api', `HTTP Response status: ${response.status} ${response.statusText}`);

            if (!response.ok) {
                updateDebugInfo('api', `❌ HTTP Error: ${response.status} - ${response.statusText}`);
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            updateDebugInfo('api', `✅ HTTP response OK, parsing JSON response...`);
            const data = await response.json();

            updateDebugInfo('api', `JSON response parsed successfully`);
            updateDebugInfo('api', `Response contains 'success' key: ${data.hasOwnProperty('success')}`);

            // DEBUG: RAG Context Analysis
            if (data.data && data.data.has_rag_context !== undefined) {
                updateDebugInfo('rag', `RAG context search performed: ${data.data.has_rag_context ? 'YES' : 'NO'}`);
                if (data.data.post_ids && data.data.post_ids.length > 0) {
                    updateDebugInfo('rag', `Found relevant posts: ${data.data.post_ids.join(', ')}`);
                } else {
                    updateDebugInfo('rag', `No relevant posts found in search`);
                }
            } else {
                updateDebugInfo('rag', `RAG context information not available in response`);
            }

            // Remove loading message
            messagesDiv.removeChild(loadingDiv);

            if (data.success) {
                // DEBUG: Successful Response
                updateDebugInfo('response', `✅ API call successful`);
                updateDebugInfo('response', `Assistant response length: ${data.data.message.length} characters`);

                // Check if response contains RAG markers
                if (data.data.message.includes('||RAG-CONTEXT||')) {
                    updateDebugInfo('response', `✅ Response contains RAG context markers`);
                } else {
                    updateDebugInfo('response', `ℹ️ Response does not contain RAG context markers`);
                }

                // Add assistant response
                const assistantMessage = data.data.message;
                messages.push({ role: 'assistant', content: assistantMessage });
                saveMessages();
                renderMessages();

                updateDebugInfo('response', `Response added to conversation. Total messages: ${messages.length}`);
            } else {
                // DEBUG: Error Response
                updateDebugInfo('response', `❌ API call failed`);
                updateDebugInfo('response', `Error message: ${data.data ? data.data.message : 'No error details'}`);

                // Show error message
                const errorDiv = document.createElement('div');
                errorDiv.className = 'message assistant';
                errorDiv.style.backgroundColor = '#f8d7da';
                errorDiv.style.color = '#721c24';
                errorDiv.textContent = 'Error: ' + (data.data.message || 'Unknown error occurred');
                messagesDiv.appendChild(errorDiv);
                scrollToBottom();
            }
        } catch (error) {
            // DEBUG: Exception Handling
            updateDebugInfo('response', `❌ Exception caught: ${error.message}`);
            updateDebugInfo('api', `Request failed after ${Date.now() - startTime}ms`);

            // Remove loading message if it exists
            if (loadingDiv.parentNode) {
                messagesDiv.removeChild(loadingDiv);
            }

            // Show error message
            const errorDiv = document.createElement('div');
            errorDiv.className = 'message assistant';
            errorDiv.style.backgroundColor = '#f8d7da';
            errorDiv.style.color = '#721c24';
            errorDiv.textContent = 'Error: ' + error.message;
            messagesDiv.appendChild(errorDiv);
            scrollToBottom();

            console.error('Error sending message:', error);
        } finally {
            // Re-enable send button
            sendBtn.disabled = false;
            updateDebugInfo('response', `Request processing completed`);
        }
    }

    // Event listener for send button
    sendBtn.addEventListener('click', function () {
        const message = messageInput.value.trim();
        if (message) {
            sendMessage(message);
        }
    });

    // Allow enter key to send
    messageInput.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            const message = messageInput.value.trim();
            if (message) {
                sendMessage(message);
            }
        }
    });

    // Clear chat functionality
    clearBtn.addEventListener('click', function () {
        if (confirm('Are you sure you want to clear the chat history?')) {
            messages = [{ role: 'system', content: systemPrompt }];
            saveMessages();
            renderMessages();
            console.log('Chat history cleared');
        }
    });

    // Debug control event listeners
    const clearDebugBtn = document.getElementById('clear-debug-btn');
    const toggleDebugBtn = document.getElementById('toggle-debug-btn');

    if (clearDebugBtn) {
        clearDebugBtn.addEventListener('click', function() {
            if (confirm('Clear all debug information?')) {
                clearDebugInfo();
            }
        });
    }

    if (toggleDebugBtn) {
        toggleDebugBtn.addEventListener('click', function() {
            toggleDebugSections();
            this.textContent = this.textContent.includes('Show') ? 'Hide Debug Sections' : 'Show Debug Sections';
        });
    }

    // Load messages on page load
    loadMessages();

    // Debug: Log initial state
    updateDebugInfo('system', `ChatBot initialized with ${messages.length} messages`);
    updateDebugInfo('system', `System prompt loaded: ${systemPrompt.length} characters`);
    console.log('ChatBot initialized. Messages array:', messages);
});
