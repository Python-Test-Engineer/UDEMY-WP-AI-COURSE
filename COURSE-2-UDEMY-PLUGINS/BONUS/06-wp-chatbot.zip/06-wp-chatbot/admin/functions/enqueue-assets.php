<?php
// Enqueue admin assets (CSS and JavaScript)

function wp_chatbot_enqueue_admin_assets($hook) {
    // Only load on our plugin's admin page
    if ($hook !== 'toplevel_page_wp-chatbot-settings') {
        return;
    }
    
    // Enqueue admin styles
    wp_enqueue_style(
        'wp-chatbot-admin-styles',
        WP_CHATBOT_PLUGIN_URL . 'admin/assets/css/admin-styles.css',
        array(),
        WP_CHATBOT_VERSION
    );
    
    // Enqueue chatbot JavaScript
    wp_enqueue_script(
        'wp-chatbot-js',
        WP_CHATBOT_PLUGIN_URL . 'admin/assets/js/chatbot.js',
        array('jquery'),
        WP_CHATBOT_VERSION,
        true
    );
    
    // Localize script to pass WordPress data to JavaScript
    wp_localize_script('wp-chatbot-js', 'wpChatbot', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('chatbot_nonce')
    ));
}
