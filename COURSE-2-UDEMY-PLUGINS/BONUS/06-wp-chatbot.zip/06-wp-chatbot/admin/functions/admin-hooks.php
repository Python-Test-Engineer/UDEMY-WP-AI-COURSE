<?php
// Admin hooks for ChatBot settings

// Add admin menu
add_action('admin_menu', 'wp_chatbot_settings_menu');

function wp_chatbot_settings_menu() {
    add_menu_page(
        '06 CHATBOT',           // Page title
        '06 CHATBOT',           // Menu title
        'manage_options',       // Capability
        'wp-chatbot-settings',  // Menu slug
        'wp_chatbot_render_settings_page', // Callback function
        'dashicons-format-chat', // Icon
        3.9            // Position
    );
}
