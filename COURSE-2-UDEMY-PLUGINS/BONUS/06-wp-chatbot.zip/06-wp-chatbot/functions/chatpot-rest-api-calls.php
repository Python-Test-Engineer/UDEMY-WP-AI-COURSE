<?php
/**
 * Fetch context from FTS REST API with improved parameters
 */
function wp_chatbot_fetch_search_context($query) {
    // Use local FTS REST API endpoint with 3 results for better context (reduced from 5)
    $search_url = site_url('/wp-json/fts/v1/search?query=' . urlencode($query) . '&count=3');

    // Debug: Log the constructed URL
    error_log('FTS Search URL: ' . $search_url);

    $search_response = wp_remote_get($search_url, array(
        'timeout' => 10
    ));

    // If successful, return context data
    if (!is_wp_error($search_response)) {
        $search_body = wp_remote_retrieve_body($search_response);
        $search_data = json_decode($search_body, true);

        if (isset($search_data['context']) && !empty($search_data['context'])) {
            error_log('Found context with length: ' . strlen($search_data['context']));
            return $search_data;
        }
    }
    
    error_log('No context found for query: ' . $query);
    return array();
}

/**
 * Make request to the appropriate API (OpenAI or Groq)
 */
function wp_chatbot_make_api_request($api_config, $messages) {
    $response = wp_remote_post($api_config['api_endpoint'], array(
        'timeout' => 60,
        'headers' => array(
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $api_config['api_key']
        ),
        'body' => json_encode(array(
            'model' => $api_config['model'],
            'messages' => $messages,
            'max_tokens' => 1024
        ))
    ));

    // Check for errors
    if (is_wp_error($response)) {
        return array('success' => false, 'message' => $response->get_error_message());
    }

    // Get response body
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    // Check if API returned an error
    if (isset($data['error'])) {
        return array('success' => false, 'message' => $data['error']['message']);
    }

    return array('success' => true, 'data' => $data);
}

/**
 * Format the response including RAG context if available
 */
function wp_chatbot_format_response($api_data, $rag_data) {
    if (!isset($api_data['choices'][0]['message']['content'])) {
        return array('message' => 'No response from API');
    }

    $assistant_message = $api_data['choices'][0]['message']['content'];

    // Prepend RAG context to the response if available with simple formatting
    if (!empty($rag_data['rag_context'])) {
        // Get post IDs for display
        $post_ids = isset($rag_data['search_data']['post_ids']) ? $rag_data['search_data']['post_ids'] : array();
        $post_ids_text = !empty($post_ids) ? ' (Post IDs: ' . implode(', ', $post_ids) . ')' : '';

        // Simple format with RAG-CONTEXT markers
        $formatted_response = "||RAG-CONTEXT||" . $post_ids_text . "\n\n";
        $formatted_response .= $rag_data['rag_context'];
        $formatted_response .= "\n\n||RAG-CONTEXT||\n\n";
        $formatted_response .= "<br><br>***** AI ANSWER:\n\n";
        $formatted_response .= $assistant_message;

        $assistant_message = $formatted_response;
    }

    return array(
        'message' => $assistant_message,
        'has_rag_context' => !empty($rag_data['rag_context']),
        'post_ids' => isset($rag_data['search_data']['post_ids']) ? $rag_data['search_data']['post_ids'] : array()
    );
}
