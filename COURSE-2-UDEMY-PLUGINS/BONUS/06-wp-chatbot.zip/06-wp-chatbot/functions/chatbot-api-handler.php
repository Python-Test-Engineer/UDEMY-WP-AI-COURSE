<?php
// ChatBot API Handler - handles AJAX requests to OpenAI

// Handle AJAX request for chatbot
add_action('wp_ajax_chatbot_send_message', 'wp_chatbot_send_message');
add_action('wp_ajax_nopriv_chatbot_send_message', 'wp_chatbot_send_message'); // Allow non-logged-in users

/**
 * Main function to handle chatbot message sending
 */
function wp_chatbot_send_message() {
    // Step 1: Verify nonce
    if (!wp_chatbot_verify_nonce()) {
        return;
    }
    
    // Step 2: Get and validate API configuration
    $api_config = wp_chatbot_get_api_config();
    if (!$api_config['success']) {
        wp_send_json_error(array('message' => $api_config['message']));
        return;
    }
    
    // Step 3: Get and validate messages
    $messages = wp_chatbot_get_messages();
    if (!$messages['success']) {
        wp_send_json_error(array('message' => $messages['message']));
        return;
    }
    
    // Step 4: Load system prompt
    $system_prompt = wp_chatbot_load_system_prompt();
    
    // Step 5: Get RAG context
    $rag_data = wp_chatbot_get_rag_context($messages['data'], $system_prompt);
    
    // Step 6: Make API request
    $api_response = wp_chatbot_make_api_request($api_config['data'], $rag_data['messages']);
    
    if (!$api_response['success']) {
        wp_send_json_error(array('message' => $api_response['message']));
        return;
    }
    
    // Step 7: Format and return response
    $formatted_response = wp_chatbot_format_response($api_response['data'], $rag_data);
    
    wp_send_json_success($formatted_response);
}

/**
 * Verify nonce for security
 */
function wp_chatbot_verify_nonce() {
    $nonce = isset($_POST['nonce']) ? $_POST['nonce'] : '';
    
    if (!wp_verify_nonce($nonce, 'chatbot_nonce') && !wp_verify_nonce($nonce, 'wp_chatbot_nonce')) {
        wp_send_json_error(array('message' => 'Nonce verification failed'));
        return false;
    }
    
    return true;
}

/**
 * Get and validate API configuration
 */
function wp_chatbot_get_api_config() {
    // Get the API key - check for custom key first, then fall back to stored key, then env vars
    $api_key = isset($_POST['custom_api_key']) && !empty($_POST['custom_api_key'])
        ? sanitize_text_field($_POST['custom_api_key'])
        : get_option('wp_chatbot_api_key');

    // If no stored key, try to get from environment (GROQ first, then OPENAI)
    if (empty($api_key)) {
        $api_key = getenv('GROQ_API_KEY') ?: getenv('OPENAI_API_KEY');
    }

    if (empty($api_key)) {
        return array('success' => false, 'message' => 'API key not configured');
    }

    // Determine API endpoint based on API key format or preference
    $api_endpoint = 'https://api.openai.com/v1/chat/completions';
    $model = 'gpt-4o-mini';

    // If API key starts with 'gsk_', it's likely Groq
    if (strpos($api_key, 'gsk_') === 0) {
        $api_endpoint = 'https://api.groq.com/openai/v1/chat/completions';
        $model = 'llama-3.1-8b-instant';
    }
    
    return array(
        'success' => true,
        'data' => array(
            'api_key' => $api_key,
            'api_endpoint' => $api_endpoint,
            'model' => $model
        )
    );
}

/**
 * Get and validate messages from request
 */
function wp_chatbot_get_messages() {
    $messages = isset($_POST['messages']) ? json_decode(stripslashes($_POST['messages']), true) : array();

    if (empty($messages)) {
        return array('success' => false, 'message' => 'No messages provided');
    }
    
    return array('success' => true, 'data' => $messages);
}

/**
 * Load system prompt from file
 */
function wp_chatbot_load_system_prompt() {
    $system_prompt_content = '';
    $system_prompt_file = WP_CHATBOT_PLUGIN_DIR . 'admin/includes/inc-system-prompt.php';
    
    if (file_exists($system_prompt_file)) {
        ob_start();
        include $system_prompt_file;
        $system_prompt_content = ob_get_clean();
    }
    
    return $system_prompt_content;
}

/**
 * Get RAG context from FTS REST API
 *
 * @param array $messages The conversation messages
 * @param string $system_prompt The base system prompt
 * @return array Array containing messages with context and RAG data
 */
function wp_chatbot_get_rag_context($messages, $system_prompt) {
    // Get the latest user message as the query
    $user_query = wp_chatbot_get_latest_user_query($messages);
    $rag_context = '';
    $search_data = array();

    // Only search if we have a meaningful query
    if (!empty($user_query) && strlen(trim($user_query)) > 2) {
        // Use the FTS REST API with the user's query
        $search_data = wp_chatbot_fetch_search_context($user_query);

        if (!empty($search_data['context'])) {
            $rag_context = $search_data['context'];

            // Inject context into system prompt
            $post_ids = isset($search_data['post_ids']) ? $search_data['post_ids'] : array();
            $post_ids_text = !empty($post_ids) ? ' (Source Post IDs: ' . implode(', ', $post_ids) . ')' : '';

            $context_addition = "\n\nRELEVANT CONTEXT FROM DATABASE SEARCH: " . $rag_context . $post_ids_text;
            $system_prompt .= $context_addition;
        }
    }

    // Ensure first message is system prompt with context included
    if (!empty($messages) && $messages[0]['role'] === 'system') {
        $messages[0]['content'] = $system_prompt;
    }

    return array(
        'messages' => $messages,
        'rag_context' => $rag_context,
        'search_data' => $search_data
    );
}

/**
 * Extract the latest user query from messages
 */
function wp_chatbot_get_latest_user_query($messages) {
    foreach (array_reverse($messages) as $message) {
        if (isset($message['role']) && $message['role'] === 'user') {
            return $message['content'];
        }
    }
    return '';
}

require_once WP_CHATBOT_PLUGIN_DIR . 'functions/chatpot-rest-api-calls.php';
