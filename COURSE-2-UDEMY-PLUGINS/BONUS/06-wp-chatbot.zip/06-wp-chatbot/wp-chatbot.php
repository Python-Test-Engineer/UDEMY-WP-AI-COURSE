<?php
/*
Plugin Name: ✅ 06 UDEMY CHATBOT WITH MEMORY
Description: A ChatBot plugin for WordPress that integrates with OpenAI's API and includes conversation memory using localStorage.
Version: 1.0.0
Author: Craig West
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('WP_CHATBOT_VERSION', '1.0.0');
define('WP_CHATBOT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WP_CHATBOT_PLUGIN_URL', plugin_dir_url(__FILE__));

// Load environment variables from .env file
function wp_chatbot_load_env() {
    $env_file = ABSPATH . '../_COMMON/.env'; // Adjust path as needed
    if (file_exists($env_file)) {
        $lines = file($env_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            if (strpos(trim($line), '#') === 0) continue; // Skip comments
            list($key, $value) = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);
            if (!empty($key)) {
                putenv("$key=$value");
                $_ENV[$key] = $value;
            }
        }
    }
}
wp_chatbot_load_env();

// Register settings for API key storage
function wp_chatbot_register_settings() {
    register_setting('wp_chatbot_settings', 'wp_chatbot_api_key');
}
add_action('admin_init', 'wp_chatbot_register_settings');

// Process form submissions (API key save and show/hide toggle)
function wp_chatbot_process_forms() {
    // Check if user has permission
    if (!current_user_can('manage_options')) {
        return;
    }
    
    // Handle API key visibility toggle
    if (isset($_POST['toggle_chatbot_key_visibility']) && check_admin_referer('wp_chatbot_toggle_nonce')) {
        // Get current visibility state from transient
        $is_visible = get_transient('wp_chatbot_show_key_' . get_current_user_id());
        
        // Toggle the visibility state
        if ($is_visible) {
            delete_transient('wp_chatbot_show_key_' . get_current_user_id());
        } else {
            set_transient('wp_chatbot_show_key_' . get_current_user_id(), true, 3600); // 1 hour
        }
        
        // Redirect to prevent form resubmission
        wp_redirect(admin_url('admin.php?page=wp-chatbot-settings'));
        exit;
    }
    
    // Handle API key save
    if (isset($_POST['save_chatbot_api_key']) && check_admin_referer('wp_chatbot_save_key_nonce')) {
        $api_key = sanitize_text_field($_POST['wp_chatbot_api_key']);
        update_option('wp_chatbot_api_key', $api_key);
        
        // Store success message in transient
        set_transient('wp_chatbot_message', 'API Key saved successfully!', 30);
        
        wp_redirect(admin_url('admin.php?page=wp-chatbot-settings'));
        exit;
    }
}
add_action('admin_init', 'wp_chatbot_process_forms');

// Include admin functionality
require_once WP_CHATBOT_PLUGIN_DIR . 'admin/functions/admin-hooks.php';
require_once WP_CHATBOT_PLUGIN_DIR . 'admin/functions/render-admin-page.php';
require_once WP_CHATBOT_PLUGIN_DIR . 'admin/functions/enqueue-assets.php';

// Include API handler
require_once WP_CHATBOT_PLUGIN_DIR . 'functions/chatbot-api-handler.php';

// Include shortcode functionality
require_once WP_CHATBOT_PLUGIN_DIR . 'shortcodes/chatbot-shortcode.php';

// Enqueue admin scripts and styles
add_action('admin_enqueue_scripts', 'wp_chatbot_enqueue_admin_assets');

// Activation hook
function wp_chatbot_activate() {
    // Set default options on activation
    add_option('wp_chatbot_api_key', '');
    
    // Flush rewrite rules
    flush_rewrite_rules();
}
register_activation_hook(__FILE__, 'wp_chatbot_activate');

// Deactivation hook
function wp_chatbot_deactivate() {
    // Clean up transients
    global $wpdb;
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_wp_chatbot_%'");
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_wp_chatbot_%'");
    
    // Flush rewrite rules
    flush_rewrite_rules();
}
register_deactivation_hook(__FILE__, 'wp_chatbot_deactivate');
