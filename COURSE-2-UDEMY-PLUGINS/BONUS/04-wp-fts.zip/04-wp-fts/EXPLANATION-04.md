# WordPress Full Text Search Plugin (05-wp-fts) - Detailed Explanation

## 🎯 Plugin Overview

The **WordPress Full Text Search (FTS)** plugin creates a dedicated database table optimized for full-text search functionality across WordPress posts. This plugin demonstrates advanced WordPress development concepts including custom database tables, FULLTEXT indexing, REST API endpoints, AJAX functionality, and admin interface design.

## 📋 What This Plugin Does

This plugin enhances WordPress's native search capabilities by:

1. **Creating a Custom Database Table**: Establishes a dedicated table (`wp_posts_fts`) with FULLTEXT indexing for efficient search operations
2. **Indexing Post Data**: Automatically indexes published posts with title, content, categories, tags, and custom meta fields
3. **Providing REST API**: Offers a RESTful API endpoint for programmatic search queries
4. **Admin Management Interface**: Includes a comprehensive admin dashboard for table management and testing

## 🏗️ Architecture & Components

### Core Files Structure
```
05-wp-fts/
├── wp-fts-plugin.php          # Main plugin file with core logic
├── templates/
│   └── admin-page.php         # Admin dashboard template
├── assets/
│   ├── css/
│   │   └── admin-styles.css   # Admin interface styling
│   └── js/
│       └── admin-script.js    # Admin JavaScript functionality
└── EXPLANATION-05.md          # This explanation document
```

## 🔧 Technical Implementation

### 1. Plugin Architecture (wp-fts-plugin.php)

#### Class Structure: FTS_Plugin
```php
class FTS_Plugin {
    private $table_name;
    // ... methods for activation, admin menu, assets, etc.
}
```

#### Key Methods:
- `__construct()`: Initializes the plugin and registers hooks
- `activate()`: Creates database table and populates with existing posts
- `add_admin_menu()`: Adds the admin menu page
- `enqueue_admin_assets()`: Loads CSS and JavaScript for admin interface
- `render_admin_page()`: Displays the admin dashboard
- `handle_search_request()`: Processes REST API search requests

### 2. Database Design

#### Table Schema
```sql
CREATE TABLE wp_posts_fts (
    id bigint(20) NOT NULL AUTO_INCREMENT,
    guid varchar(255) NOT NULL,           -- Unique identifier
    post_id bigint(20) NOT NULL,          -- WordPress post ID
    post_title text NOT NULL,             -- Post title
    post_content longtext NOT NULL,       -- Post content
    categories text,                      -- Comma-separated categories
    tags text,                           -- Comma-separated tags
    custom_meta_data longtext,           -- JSON-encoded meta fields
    last_updated datetime DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY guid (guid),
    KEY post_id (post_id)
);
```

#### FULLTEXT Indexing
```sql
ALTER TABLE wp_posts_fts ADD FULLTEXT INDEX ft_post_title (post_title);
```

### 3. Data Population Process

The plugin populates the FTS table by:
1. Querying all published posts
2. Extracting categories, tags, and custom meta fields
3. Serializing meta data as JSON
4. Generating unique GUIDs for each entry
5. Using `wp_insert()` for database insertion

### 4. Admin Interface (templates/admin-page.php)

#### Features:
- **Statistics Dashboard**: Displays total indexed posts
- **Action Buttons**: Regenerate table and view table information
- **REST API Tester**: Interactive form to test search functionality
- **Response Display**: Shows formatted JSON responses

#### JavaScript Integration:
- AJAX calls for table regeneration
- Dynamic table information display
- Real-time API testing with fetch requests
- Clipboard functionality for endpoint URLs

### 5. REST API Implementation

#### Endpoint: `/wp-json/fts/v1/search`
**Parameters:**
- `query` (required): Search term(s)
- `count` (optional): Number of results (default: 3)

**Example Request:**
```
GET /wp-json/fts/v1/search?query=wordpress&count=5
```

**Response Format:**
```json
{
    "query": "wordpress",
    "post_ids": [1, 5, 12],
    "context": "Post content excerpt...",
    "debug": {
        "table_name": "wp_posts_fts",
        "total_posts_in_table": 25,
        "search_method": "success"
    }
}
```

## 🔍 Search Algorithm

### Primary Method: FULLTEXT Search
```sql
SELECT post_id, post_title, post_content,
       MATCH(post_title) AGAINST('query' IN BOOLEAN MODE) * 2 +
       MATCH(post_content) AGAINST('query' IN BOOLEAN MODE) as relevance_score
FROM wp_posts_fts
WHERE MATCH(post_title, post_content) AGAINST('query' IN BOOLEAN MODE)
ORDER BY relevance_score DESC, post_id ASC
LIMIT {count}
```

### Fallback Method: LIKE Search
If FULLTEXT search fails, the plugin falls back to SQL LIKE queries:
```sql
WHERE post_title LIKE '%term%' OR post_content LIKE '%term%'
```

### Relevance Scoring
- Title matches are weighted 2x higher than content matches
- Results ordered by relevance score descending

## 🎨 Admin Interface Design

### CSS Features (admin-styles.css)
- **Responsive Grid Layout**: Statistics cards adapt to screen size
- **Modern UI Elements**: Rounded corners, subtle shadows, hover effects
- **Loading Animations**: Spinner animations for async operations
- **Color-coded Messages**: Success/error state styling

### JavaScript Features (admin-script.js)
- **AJAX Operations**: Async table regeneration and info retrieval
- **User Feedback**: Loading states and success/error messages
- **API Testing**: Real-time REST API interaction
- **Clipboard Integration**: Modern clipboard API with fallbacks
- **Accessibility**: Keyboard navigation and ARIA support

## 🚀 Usage Examples

### 1. Basic Search via REST API
```bash
curl "https://yoursite.com/wp-json/fts/v1/search?query=wordpress&count=3"
```

### 2. Programmatic Usage in PHP
```php
$response = wp_remote_get(add_query_arg([
    'query' => 'search term',
    'count' => 5
], rest_url('fts/v1/search')));

$data = json_decode(wp_remote_retrieve_body($response));
$post_ids = $data->post_ids;
```

### 3. Integration with AI/Chatbots
The plugin is designed to work with AI systems by providing:
- Structured post data for context
- Relevance-ranked search results
- Clean text excerpts without HTML

## 🔧 Administration

### Accessing the Admin Interface
1. Navigate to **WordPress Admin → 05 FTS MANAGER**
2. View statistics and current table status
3. Use "Regenerate Table" to refresh indexed content
4. Test API functionality with the built-in tester

### Maintenance Tasks
- **Regenerate Table**: Rebuilds the entire FTS table from current posts
- **View Table Info**: Shows table statistics and FULLTEXT index status
- **Test API**: Verify search functionality works correctly

## 📊 Performance Considerations

### Database Optimization
- FULLTEXT indexing for fast search operations
- Proper indexing on `post_id` for efficient lookups
- JSON storage for complex meta data structures

### Query Optimization
- Boolean mode FULLTEXT searches for precise matching
- Relevance scoring for result ranking
- LIMIT clauses to prevent excessive result sets

### Memory Management
- Streaming post processing during table regeneration
- Chunked data handling for large sites
- Efficient memory usage with proper cleanup

## 🛠️ Development Concepts Demonstrated

### WordPress Development Skills
1. **Plugin Architecture**: Proper class-based plugin structure
2. **Database Operations**: Custom table creation and management
3. **Admin Interfaces**: Custom admin pages with proper WordPress styling
4. **REST API**: Registering custom endpoints with proper validation
5. **AJAX Integration**: Server-side processing with client-side feedback
6. **Asset Management**: Proper enqueueing of CSS and JavaScript
7. **Security**: Nonces, sanitization, and permission checks

### Advanced Concepts
1. **FULLTEXT Indexing**: MySQL full-text search capabilities
2. **Search Algorithms**: Relevance scoring and result ranking
3. **API Design**: RESTful endpoint design and documentation
4. **JavaScript/AJAX**: Modern JavaScript with jQuery integration
5. **CSS Architecture**: Responsive design and modern UI patterns

## 🔐 Security Features

- **Nonce Verification**: All AJAX requests protected with WordPress nonces
- **Permission Checks**: Admin-only access to management functions
- **Input Sanitization**: All user inputs properly sanitized
- **SQL Injection Prevention**: Prepared statements for all database queries
- **XSS Protection**: Proper output escaping in templates

## 🎓 Learning Outcomes

After studying this plugin, students will understand:

1. **Advanced WordPress Plugin Development**
   - Custom database table creation
   - Admin interface design
   - REST API implementation

2. **Database Design & Optimization**
   - FULLTEXT indexing strategies
   - Query optimization techniques
   - Performance considerations

3. **Modern JavaScript Integration**
   - AJAX request handling
   - DOM manipulation
   - User experience enhancements

4. **API Design Principles**
   - RESTful endpoint creation
   - Request/response handling
   - Error management

5. **Security Best Practices**
   - WordPress security functions
   - Input validation and sanitization
   - Permission management

## 🚀 Next Steps & Extensions

### Potential Enhancements
1. **Advanced Search Features**
   - Fuzzy matching with SOUNDEX/Levenshtein
   - Category/tag filtering
   - Date range searches

2. **Performance Improvements**
   - Search result caching (Redis/Memcached)
   - Asynchronous indexing
   - Search analytics

3. **Additional Features**
   - Search suggestions/autocomplete
   - Faceted search interface
   - Export/import functionality

4. **Integration Options**
   - WooCommerce product search
   - Custom post type support
   - Multilingual search (WPML/Polylang)

This plugin serves as a comprehensive example of professional WordPress development, demonstrating how to build scalable, maintainable plugins that integrate deeply with WordPress core functionality.
