<?php
/**
 * Plugin Name: ✅ 04 UDEMY FULL TEXT SEARCH
 * Plugin URI: https://example.com/fts-plugin
 * Description: Creates a table for full-text search functionality with post data.
 * Version: 1.0.0
 * Author: Craig West
 * Author URI: https://example.com
 * License: GPL2
 * Text Domain: fts-plugin
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('FTS_PLUGIN_FILE', __FILE__);
define('FTS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('FTS_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * FTS Plugin Class
 */
class FTS_Plugin {
    
    private $table_name;
    
    /**
     * Constructor
     */
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'posts_fts';
        
        // Register activation hook
        register_activation_hook(__FILE__, array($this, 'activate'));
        
        // Add admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // Enqueue admin assets
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
    }
    #region SQL
    /**
     * Plugin activation - Create table and populate data
     */
    public function activate() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE {$this->table_name} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            guid varchar(255) NOT NULL,
            post_id bigint(20) NOT NULL,
            post_title text NOT NULL,
            post_content longtext NOT NULL,
            categories text,
            tags text,
            custom_meta_data longtext,
            last_updated datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY guid (guid),
            KEY post_id (post_id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Add FULLTEXT index on post_title
        $this->ensure_fulltext_index();
        
        // Populate table with existing posts
        $this->populate_table();
    }
    #endregion
    #region FTS
    /**
     * Ensure FULLTEXT indexes exist on post_title only
     */
    public function ensure_fulltext_index() {
        global $wpdb;

        // Check existing FULLTEXT indexes
        $indexes = $wpdb->get_results("SHOW INDEX FROM {$this->table_name} WHERE Index_type = 'FULLTEXT'");

        $existing_indexes = array();
        foreach ($indexes as $index) {
            $existing_indexes[] = $index->Key_name;
        }

        // Create FULLTEXT index on just title
        if (!in_array('ft_post_title', $existing_indexes)) {
            $wpdb->query("ALTER TABLE {$this->table_name} ADD FULLTEXT INDEX ft_post_title (post_title)");
        }
    }
    #endregion
    #region ADMIN
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            'FTS Manager',
            '04 FTS MANAGER',
            'manage_options',
            'fts-manager',
            array($this, 'render_admin_page'),
            'dashicons-search',
            3.5
        );
    }
    
    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets($hook) {
        if ($hook === 'toplevel_page_fts-manager') {
            wp_enqueue_style(
                'fts-admin-css',
                FTS_PLUGIN_URL . 'assets/css/admin-styles.css',
                array(),
                '1.0.0'
            );
            
            wp_enqueue_script(
                'fts-admin-js',
                FTS_PLUGIN_URL . 'assets/js/admin-script.js',
                array('jquery'),
                '1.0.0',
                true
            );
            
            wp_localize_script('fts-admin-js', 'ftsData', array(
                'nonce' => wp_create_nonce('fts_action'),
                'ajax_url' => admin_url('admin-ajax.php')
            ));
        }
    }
    
    /**
     * Render admin page
     */
    public function render_admin_page() {
        global $wpdb;
        
        // Get statistics
        $total_posts = $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name}");
        
        include FTS_PLUGIN_DIR . 'templates/admin-page.php';
    }
    #region POPULATE
    /**
     * Populate table with published posts
     */
    private function populate_table() {
        global $wpdb;
        
        $args = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'orderby' => 'ID',
            'order' => 'ASC'
        );
        
        $posts = get_posts($args);
        $processed = 0;
        
        foreach ($posts as $post) {
            // Get categories as CSV
            $categories = wp_get_post_categories($post->ID, array('fields' => 'names'));
            $categories_csv = implode(', ', $categories);
            
            // Get tags as CSV
            $tags = wp_get_post_tags($post->ID, array('fields' => 'names'));
            $tags_csv = implode(', ', $tags);
            
            // Get custom meta fields (exclude system meta that starts with _)
            $meta_keys = $wpdb->get_results($wpdb->prepare(
                "SELECT meta_key, meta_value FROM {$wpdb->postmeta} 
                WHERE post_id = %d AND meta_key NOT LIKE '\_%%'",
                $post->ID
            ));
            
            $custom_meta = array();
            foreach ($meta_keys as $meta) {
                $custom_meta[$meta->meta_key] = maybe_unserialize($meta->meta_value);
            }
            
            $custom_meta_json = json_encode($custom_meta);
            
            // Generate GUID
            $guid = wp_generate_uuid4();
            
            // Insert or update
            $wpdb->replace(
                $this->table_name,
                array(
                    'guid' => $guid,
                    'post_id' => $post->ID,
                    'post_title' => $post->post_title,
                    'post_content' => $post->post_content,
                    'categories' => $categories_csv,
                    'tags' => $tags_csv,
                    'custom_meta_data' => $custom_meta_json,
                    'last_updated' => current_time('mysql')
                ),
                array('%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s')
            );
            
            $processed++;
        }
        
        return $processed;
    }
    
    /**
     * AJAX: Regenerate table
     */
    public function ajax_regenerate_table() {
        check_ajax_referer('fts_action', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Unauthorized'));
        }
        
        global $wpdb;
        $wpdb->query("TRUNCATE TABLE {$this->table_name}");
        
        $processed = $this->populate_table();
        
        wp_send_json_success(array('processed' => $processed));
    }
    #region TABLE INFO
    /**
     * AJAX: Get table information
     */
    public function ajax_get_table_info() {
        check_ajax_referer('fts_action', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Unauthorized'));
        }
        
        global $wpdb;
        
        $info = array();
        
        // Get table row count
        $info['Total Rows'] = $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name}");
        
        // Get table size (approximate)
        $table_size = $wpdb->get_row("SHOW TABLE STATUS LIKE '{$this->table_name}'");
        if ($table_size) {
            $size_mb = round($table_size->Data_length / 1024 / 1024, 2);
            $info['Table Size'] = $size_mb . ' MB';
        }
        
        // Check if FULLTEXT index exists
        $indexes = $wpdb->get_results("SHOW INDEX FROM {$this->table_name} WHERE Index_type = 'FULLTEXT'");
        $info['FULLTEXT Index'] = !empty($indexes) ? 'Yes (post_title)' : 'No';
        
        // Get last updated time
        $last_updated = $wpdb->get_var("SELECT MAX(last_updated) FROM {$this->table_name}");
        $info['Last Updated'] = $last_updated ? $last_updated : 'Never';
        
        wp_send_json_success($info);
    }
    #region REST API
    /**
     * Register REST API routes
     */
    public function register_rest_routes() {
        register_rest_route('fts/v1', '/search', array(
            'methods' => 'GET',
            'callback' => array($this, 'handle_search_request'),
            'permission_callback' => '__return_true',
            'args' => array(
                'query' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                    'description' => 'Search query string'
                ),
                'count' => array(
                    'required' => false,
                    'type' => 'integer',
                    'default' => 3,
                    'description' => 'Number of results to return (default: 3)'
                )
            )
        ));
    }
    
    /**
     * Handle search request via REST API
     */
    public function handle_search_request($request) {
        global $wpdb;
        
        $query = $request->get_param('query');
        $count = $request->get_param('count');
        
        // Validate query
        if (empty(trim($query))) {
            return new WP_Error('invalid_query', 'Search query cannot be empty', array('status' => 400));
        }
        
        // Check if table exists and has data
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$this->table_name}'") === $this->table_name;
        if (!$table_exists) {
            return new WP_Error('table_not_found', 'FTS table does not exist. Please activate the plugin.', array('status' => 500));
        }
        
        $total_posts = $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name}");
        if ($total_posts == 0) {
            return new WP_Error('empty_table', 'FTS table is empty. Please regenerate the table first.', array('status' => 200));
        }
        
        // Sanitize and prepare query for FULLTEXT search
        $search_query = sanitize_text_field($query);
        
        // Try FULLTEXT search first - search only in title using Natural Language mode
        $sql = $wpdb->prepare(
            "SELECT post_id, post_title, post_content,
                    MATCH(post_title) AGAINST(%s IN NATURAL LANGUAGE MODE) as relevance_score
             FROM {$this->table_name}
             WHERE MATCH(post_title) AGAINST(%s IN NATURAL LANGUAGE MODE)
             ORDER BY relevance_score DESC, post_id ASC
             LIMIT %d",
            $search_query,
            $search_query,
            absint($count)
        );
        
        $results = $wpdb->get_results($sql);
        
        // If FULLTEXT doesn't work, fall back to LIKE search
        if (empty($results)) {
            $search_terms = explode(' ', $search_query);
            $like_conditions = array();
            foreach ($search_terms as $term) {
                $term = trim($term);
                if (!empty($term)) {
                    $like_conditions[] = $wpdb->prepare(
                        "(post_title LIKE %s OR post_content LIKE %s)", 
                        '%' . $wpdb->esc_like($term) . '%',
                        '%' . $wpdb->esc_like($term) . '%'
                    );
                }
            }
            
            if (!empty($like_conditions)) {
                $where_clause = implode(' OR ', $like_conditions);
                $sql = $wpdb->prepare(
                    "SELECT post_id, post_title, post_content, 0 as relevance_score
                     FROM {$this->table_name} 
                     WHERE {$where_clause}
                     ORDER BY post_id ASC
                     LIMIT %d",
                    absint($count)
                );
                $results = $wpdb->get_results($sql);
            }
        }
        
        // Prepare response data
        $post_ids = array();
        $context = '';
        
        if (!empty($results)) {
            foreach ($results as $result) {
                $post_ids[] = intval($result->post_id);
                $context .= $result->post_title . ' ' . wp_strip_all_tags($result->post_content) . ' ';
            }
            $context = trim(preg_replace('/\s+/', ' ', $context));
        }
        
        // Prepare response
        $response = array(
            'query' => $search_query,
            'post_ids' => $post_ids, // Useful for citations of sources
            'context' => $context, // This will be the RAG context
            'debug' => array(
                'table_name' => $this->table_name,
                'total_posts_in_table' => $total_posts,
                'search_method' => !empty($results) ? 'success' : 'no_results'
            )
        );
        
        return rest_ensure_response($response);
    }
}

// Initialize the plugin
$fts_plugin = new FTS_Plugin();

// AJAX handlers
add_action('wp_ajax_fts_regenerate_table', array($fts_plugin, 'ajax_regenerate_table'));
add_action('wp_ajax_fts_get_table_info', array($fts_plugin, 'ajax_get_table_info'));

// REST API handlers
add_action('rest_api_init', array($fts_plugin, 'register_rest_routes'));
