<?php
/**
 * Admin Page Template for FTS Plugin
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <div class="fts-stats">
        <div class="stats-card">
            <h3>Total Posts in FTS Table</h3>
            <div class="stats-number"><?php echo esc_html($total_posts); ?></div>
            <p>Posts currently stored in the full-text search table</p>
        </div>
    </div>
    
    <div class="fts-actions">
        <h2>Actions</h2>
        <p style="color: green;font-size:1.25rem;">Always regenerate the table when you make changes to your content!</p>
        <div class="action-buttons">
            <button id="regenerate-table" class="button button-primary">
                <span class="button-text">Regenerate Table</span>
                <span class="button-spinner" style="display: none;">Loading...</span>
            </button>
            <button id="view-table-info" class="button">
                View Table Information
            </button>
        </div>
    </div>
    
    <div id="message" class="notice" style="display: none;"></div>
    
    <div id="table-info" class="postbox" style="display: none; margin-top: 20px;">
        <h3 class="hndle">Table Information</h3>
        <div class="inside">
            <div id="table-details"></div>
        </div>
    </div>

    <!-- Test API Form -->
    <div class="postbox" style="margin-top: 20px;">
        <h3 class="hndle">Test REST API</h3>
        <div class="inside">
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="fts-search-query">Search Query:</label></th>
                    <td><input type="text" id="fts-search-query" class="regular-text" placeholder="Enter search term (e.g., 'wordpress')" value=""></td>
                </tr>
                <tr>
                    <th scope="row"><label for="fts-result-count">Number of Results:</label></th>
                    <td><input type="number" id="fts-result-count" class="small-text" value="3" min="1" max="20"></td>
                </tr>
            </table>
            
            <p class="submit">
                <button type="button" class="button button-primary" onclick="ftsTestAPI()">Test API</button>
                <button type="button" class="button" onclick="ftsCopyURL()">Copy Endpoint URL</button>
            </p>
            
            <div style="background: #f0f0f1; padding: 15px; border-radius: 4px; margin-bottom: 15px;">
                <strong>API Endpoint:</strong> 
                <code><?php echo home_url('/wp-json/fts/v1/search?query=foam'); ?></code>
            </div>
            
            <div id="fts-api-message" style="display: none; padding: 10px; margin: 10px 0; border-radius: 4px;"></div>
            
            <div id="fts-api-results" style="display: none;">
                <h4>Response:</h4>
                <pre id="fts-api-response" style="background: #f6f8fa; padding: 15px; border: 1px solid #e1e4e8; border-radius: 4px; overflow-x: auto; white-space: pre-wrap; word-wrap: break-word;"></pre>
            </div>
        </div>
    </div>

    <script type="text/javascript">
    function ftsShowMessage(message, type) {
        var msgDiv = document.getElementById('fts-api-message');
        msgDiv.style.display = 'block';
        msgDiv.textContent = message;
        
        if (type === 'success') {
            msgDiv.style.backgroundColor = '#d4edda';
            msgDiv.style.borderLeft = '4px solid #28a745';
            msgDiv.style.color = '#155724';
        } else if (type === 'error') {
            msgDiv.style.backgroundColor = '#f8d7da';
            msgDiv.style.borderLeft = '4px solid #dc3545';
            msgDiv.style.color = '#721c24';
        } else {
            msgDiv.style.backgroundColor = '#d1ecf1';
            msgDiv.style.borderLeft = '4px solid #17a2b8';
            msgDiv.style.color = '#0c5460';
        }
        
        setTimeout(function() {
            msgDiv.style.display = 'none';
        }, 5000);
    }
    
    function ftsTestAPI() {
        var query = document.getElementById('fts-search-query').value.trim();
        var count = document.getElementById('fts-result-count').value;
        
        if (!query) {
            ftsShowMessage('Please enter a search query', 'error');
            return;
        }
        
        var url = '<?php echo home_url('/wp-json/fts/v1/search'); ?>?query=' + encodeURIComponent(query) + '&count=' + count;
        
        console.log('Testing API:', url);
        ftsShowMessage('Testing API...', 'info');
        document.getElementById('fts-api-results').style.display = 'none';
        
        fetch(url)
            .then(function(response) {
                console.log('Response status:', response.status);
                return response.json();
            })
            .then(function(data) {
                console.log('Response data:', data);
                ftsShowMessage('API request successful!', 'success');
                document.getElementById('fts-api-response').textContent = JSON.stringify(data, null, 2);
                document.getElementById('fts-api-results').style.display = 'block';
            })
            .catch(function(error) {
                console.error('API Error:', error);
                ftsShowMessage('API request failed: ' + error.message, 'error');
                document.getElementById('fts-api-response').textContent = 'Error: ' + error.message;
                document.getElementById('fts-api-results').style.display = 'block';
            });
    }
    
    function ftsCopyURL() {
        var query = document.getElementById('fts-search-query').value.trim();
        var count = document.getElementById('fts-result-count').value;
        
        if (!query) {
            ftsShowMessage('Please enter a search query first', 'error');
            return;
        }
        
        var url = '<?php echo home_url('/wp-json/fts/v1/search'); ?>?query=' + encodeURIComponent(query) + '&count=' + count;
        
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(url).then(function() {
                ftsShowMessage('URL copied to clipboard!', 'success');
            }).catch(function() {
                ftsFallbackCopy(url);
            });
        } else {
            ftsFallbackCopy(url);
        }
    }
    
    function ftsFallbackCopy(text) {
        var textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        document.body.appendChild(textArea);
        textArea.select();
        try {
            document.execCommand('copy');
            ftsShowMessage('URL copied to clipboard!', 'success');
        } catch (err) {
            ftsShowMessage('Failed to copy URL. URL: ' + text, 'error');
        }
        document.body.removeChild(textArea);
    }
    
    // Allow Enter key to trigger test
    document.getElementById('fts-search-query').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            ftsTestAPI();
        }
    });
    </script>
</div>

<style>
.fts-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.stats-card {
    background: #f6f7f7;
    padding: 20px;
    border-radius: 8px;
    border-left: 4px solid #0073aa;
}

.stats-card h3 {
    margin: 0 0 10px 0;
    font-size: 16px;
    color: #666;
}

.stats-number {
    font-size: 32px;
    font-weight: bold;
    color: #0073aa;
    margin-bottom: 5px;
}

.fts-actions {
    background: #fff;
    padding: 20px;
    border: 1px solid #ccd0d4;
    border-radius: 8px;
}

.action-buttons {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.button-spinner {
    display: none;
}

.notice {
    margin: 20px 0;
    padding: 15px;
    border-radius: 4px;
}

.notice.success {
    background-color: #d4edda;
    border: 1px solid #c3e6cb;
    color: #155724;
}

.notice.error {
    background-color: #f8d7da;
    border: 1px solid #f5c6cb;
    color: #721c24;
}

.postbox {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 8px;
}

.postbox h3 {
    padding: 12px 15px;
    margin: 0;
    background: #f6f7f7;
    border-bottom: 1px solid #ccd0d4;
    font-size: 18px;
}

.postbox .inside {
    padding: 15px;
}

.table-info-item {
    margin-bottom: 10px;
    padding: 10px;
    background: #f6f7f7;
    border-radius: 4px;
}

.table-info-item strong {
    display: inline-block;
    width: 150px;
    color: #333;
}
</style>
