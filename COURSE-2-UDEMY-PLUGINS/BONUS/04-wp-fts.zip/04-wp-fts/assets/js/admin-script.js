/* FTS Plugin Admin JavaScript */

jQuery(document).ready(function($) {
    'use strict';
    
    /**
     * Show message in the notice area
     * @param {string} type - 'success' or 'error'
     * @param {string} message - The message to display
     */
    function showMessage(type, message) {
        var messageDiv = $('#message');
        messageDiv.removeClass('success error');
        messageDiv.addClass(type);
        messageDiv.html('<p>' + message + '</p>');
        messageDiv.show();
        
        // Auto-hide after 5 seconds
        setTimeout(function() {
            messageDiv.fadeOut();
        }, 5000);
    }
    
    /**
     * Handle button loading state
     * @param {jQuery object} button - The button element
     * @param {boolean} isLoading - Whether to show loading state
     */
    function setButtonLoading(button, isLoading) {
        var buttonText = button.find('.button-text');
        var buttonSpinner = button.find('.button-spinner');
        
        if (isLoading) {
            button.addClass('processing');
            buttonText.hide();
            buttonSpinner.show();
        } else {
            button.removeClass('processing');
            buttonText.show();
            buttonSpinner.hide();
        }
    }
    
    /**
     * Regenerate table functionality
     */
    $('#regenerate-table').on('click', function() {
        var button = $(this);
        
        // Prevent multiple simultaneous requests
        if (button.hasClass('processing')) {
            return;
        }
        
        // Confirm action
        if (!confirm('This will regenerate the entire FTS table from your existing posts. This may take a while if you have many posts. Continue?')) {
            return;
        }
        
        setButtonLoading(button, true);
        
        $.ajax({
            url: ftsData.ajax_url,
            type: 'POST',
            data: {
                action: 'fts_regenerate_table',
                nonce: ftsData.nonce
            },
            success: function(response) {
                if (response.success) {
                    showMessage('success', 'Table regenerated successfully! Processed ' + response.data.processed + ' posts.');
                    // Reload the page to update the stats
                    setTimeout(function() {
                        location.reload();
                    }, 1500);
                } else {
                    showMessage('error', 'Error: ' + response.data.message);
                    setButtonLoading(button, false);
                }
            },
            error: function(xhr, status, error) {
                showMessage('error', 'An error occurred while regenerating the table: ' + error);
                setButtonLoading(button, false);
            }
        });
    });
    
    /**
     * View table information functionality
     */
    $('#view-table-info').on('click', function() {
        var tableInfo = $('#table-info');
        var tableDetails = $('#table-details');
        
        // Toggle visibility
        if (tableInfo.is(':visible')) {
            tableInfo.hide();
            return;
        }
        
        tableDetails.html('<p>Loading table information...</p>');
        tableInfo.show();
        
        $.ajax({
            url: ftsData.ajax_url,
            type: 'POST',
            data: {
                action: 'fts_get_table_info',
                nonce: ftsData.nonce
            },
            success: function(response) {
                if (response.success) {
                    var html = '';
                    $.each(response.data, function(key, value) {
                        html += '<div class="table-info-item">';
                        html += '<strong>' + key + ':</strong> <span>' + value + '</span>';
                        html += '</div>';
                    });
                    tableDetails.html(html);
                } else {
                    tableDetails.html('<p>Error loading table information: ' + response.data.message + '</p>');
                }
            },
            error: function(xhr, status, error) {
                tableDetails.html('<p>Error loading table information: ' + error + '</p>');
            }
        });
    });
    
    /**
     * Add some visual feedback for hover states
     */
    $('.action-buttons .button').on('mouseenter', function() {
        $(this).css('opacity', '0.9');
    }).on('mouseleave', function() {
        $(this).css('opacity', '1');
    });
    
    /**
     * Add keyboard support for accessibility
     */
    $(document).on('keydown', function(e) {
        // If Enter is pressed while a button has focus, trigger click
        if (e.key === 'Enter' && document.activeElement && document.activeElement.classList.contains('button')) {
            $(document.activeElement).click();
        }
    });
    
    /**
     * Initialize tooltips for better UX (if WordPress has tooltip support)
     */
    if (typeof wp !== 'undefined' && wp.tooltip) {
        $('.button').each(function() {
            var $this = $(this);
            if ($this.attr('title')) {
                wp.tooltip.add($this);
            }
        });
    }
    
    /**
     * Test REST API functionality
     */
    $('#test-api-btn').on('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        
        var $button = $(this);
        var $text = $button.find('.button-text');
        var $spinner = $button.find('.button-spinner');
        var $response = $('#api-response');
        var $results = $('#api-results');
        var $json = $('#api-response-json');
        var $formInputs = $('#api-test-form input');
        
        var query = $('#api-query').val().trim();
        var count = parseInt($('#api-count').val()) || 3;
        
        if (!query) {
            showMessage('error', 'Please enter a search query.');
            return;
        }
        
        // Disable form and show loading state
        $formInputs.prop('disabled', true);
        $button.prop('disabled', true);
        $text.hide();
        $spinner.show();
        $response.hide().removeClass('success error');
        $results.hide();
        $json.text('');
        
        // Get the correct REST API URL
        var baseUrl = ftsData.ajax_url.replace(/admin-ajax\.php$/, '');
        var restUrl = baseUrl + 'wp-json/fts/v1/search';
        var fullUrl = baseUrl.replace(/\/$/, '') + '/wp-json/fts/v1/search';
        
        console.log('Making request to:', fullUrl);
        
        // Make API request
        $.ajax({
            url: fullUrl,
            type: 'GET',
            data: {
                query: query,
                count: count
            },
            dataType: 'json',
            success: function(response) {
                console.log('API Response:', response);
                $response.html('<p>API request successful!</p>')
                    .addClass('success').show();
                
                // Format and display JSON response
                var formattedJson = JSON.stringify(response, null, 2);
                $json.text(formattedJson);
                $results.show();
            },
            error: function(xhr, status, error) {
                console.log('API Error:', xhr, status, error);
                var errorMessage = 'API request failed: ' + error;
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage = 'Error: ' + xhr.responseJSON.message;
                } else if (xhr.responseText) {
                    errorMessage = 'Error: ' + xhr.responseText;
                } else if (xhr.status === 0) {
                    errorMessage = 'Network error - check if REST API is enabled and URL is correct';
                } else {
                    errorMessage += ' (Status: ' + xhr.status + ')';
                }
                $response.html('<p>' + errorMessage + '</p>')
                    .addClass('error').show();
            },
            complete: function() {
                // Re-enable form and hide loading state
                $formInputs.prop('disabled', false);
                $button.prop('disabled', false);
                $text.show();
                $spinner.hide();
            }
        });
    });
    
    /**
     * Copy endpoint URL to clipboard
     */
    $('#copy-endpoint-btn').on('click', function() {
        // Get the correct REST API URL
        var restUrl = ftsData.ajax_url.replace(/admin-ajax\.php$/, '') + 'wp-json/fts/v1/search';
        var fullUrl = window.location.origin + restUrl;
        
        // Try modern clipboard API first
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(fullUrl).then(function() {
                showMessage('success', 'Endpoint URL copied to clipboard: ' + fullUrl);
            }).catch(function() {
                // Fallback for older browsers
                fallbackCopyText(fullUrl);
            });
        } else {
            // Fallback for older browsers
            fallbackCopyText(fullUrl);
        }
    });
    
    /**
     * Fallback function to copy text for older browsers
     */
    function fallbackCopyText(text) {
        var textArea = document.createElement('textarea');
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.select();
        try {
            document.execCommand('copy');
            showMessage('success', 'Endpoint URL copied to clipboard: ' + text);
        } catch (err) {
            showMessage('error', 'Failed to copy URL. Please manually copy: ' + text);
        }
        document.body.removeChild(textArea);
    }
});
