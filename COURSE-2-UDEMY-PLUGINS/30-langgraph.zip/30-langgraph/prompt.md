# IMPORTANT

11-wp-langchain has a working example of a langchain app. Copy and amend this to create the following:

## Location

Using 30-langgraph as the project folder.

## App
Create a very simple JS LangGraph app with the LangGraph code in folder src.

Create a WP plugin called 'wp-langgraph' with admin menu level item of 30. Mkae it single page.

Any supplemenatary plugin files other than the main plugin file should be in folder 'admin'.

Create and admin page to demostrate the app.

## LLM and model

Use OpenAI and gpt-4o-mini


## ENSURE

**Keep as basic as possilbe with clear explanations**

Use abundant informative console.log debug messages

## AVOID

Avoid dotenv use - a key is saved in db - see 02-wp-basic-agent where it is saved.

Avoid use of nonces - use AJAX to save form data

Avoid Node.js modules and create a browser-compatible version that simulates a graph workflow.

## Bundle

The src  folder will be bundled into the 'build' folder with @wordpress/scripts so ensure references in the plugin for the app to use this location.
